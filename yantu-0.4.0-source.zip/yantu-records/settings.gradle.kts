// 工程入口：指定插件与依赖仓库，并把 app 目录加入 Gradle 工程。
pluginManagement { repositories { mavenCentral(); google(); gradlePluginPortal() } }
dependencyResolutionManagement { repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS); repositories { mavenCentral(); google() } }
rootProject.name = "YanTuRecords"
include(":app")
