// app 模块构建配置：安装标识、支持的 Android 版本、签名、依赖和测试选项。
// namespace 对应源码包名；applicationId 是手机区分应用的安装标识，两者用途不同。
// 安装标识沿用 cn.yantu.records.next；公开源码的默认调试签名不等于已发布 APK 的签名。
plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}
android {
    namespace = "cn.yantu.records"
    compileSdk = 35
    defaultConfig { applicationId = "cn.yantu.records.next"; minSdk = 26; targetSdk = 35; versionCode = 4; versionName = "0.4.0" }
    // 公开源码不携带发布私钥。调试构建使用本机默认调试签名，Release 在本机单独签名。
    buildTypes {
        release { isMinifyEnabled = false }
    }
    testOptions {
        unitTests.isIncludeAndroidResources = true
        unitTests.all { test ->
            test.systemProperty("robolectric.dependency.repo.url", "https://repo.maven.apache.org/maven2")
            listOf("http.proxyHost","http.proxyPort","https.proxyHost","https.proxyPort","javax.net.ssl.trustStore").forEach { name ->
                System.getProperty(name)?.let { test.systemProperty(name,it) }
            }
        }
    }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
}
dependencies {
    implementation(platform("androidx.compose:compose-bom:2025.04.00"))
    implementation("androidx.activity:activity-compose:1.10.1")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")
    implementation("androidx.compose.ui:ui-tooling-preview")
    debugImplementation("androidx.compose.ui:ui-tooling")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.9.0")
    implementation("androidx.datastore:datastore-preferences:1.1.4")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.10.2")
    testImplementation("junit:junit:4.13.2")
    testImplementation("org.robolectric:robolectric:4.14.1")
    testImplementation("org.json:json:20240303")
}
