/** 中文学习注释版｜自动化验证：验证政治计分、统计口径和模拟 HTTP 请求；测试不会调用真实付费 API。 */
package cn.yantu.records

import org.junit.Assert.*
import org.junit.Test
import kotlinx.coroutines.runBlocking
import org.json.JSONObject
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL

class RulesAndAiTest {
    @Test fun politicsUsesUserRatioAndRejectsInvalidCounts() {
        val p=PoliticsParts(16,14,17,13)
        assertNull(p.validate());assertEquals(40,p.total);assertEquals(34,p.multiMax)
        assertNull(PoliticsParts(10,9,20,18).validate())
        assertEquals(p,PoliticsParts.decode(p.encode()))
        assertNotNull(PoliticsParts(17,14,17,13).validate())
        assertNotNull(PoliticsParts(16,17,17,13).validate())
        assertNotNull(PoliticsParts(-2,0,26,0).validate())
        assertNotNull(PoliticsParts(Int.MAX_VALUE,0,Int.MAX_VALUE,0).validate())
        assertEquals(0,PoliticsParts(0,0,25,0).total)
    }
    @Test fun earlyEnglishRulesAndStatisticsKeepDenominatorsSeparate() {
        assertEquals(60,scoreRule("英语二","Y2015").fullMark)
        assertEquals(100,scoreRule("英语二","Y2016").fullMark)
        assertEquals(50,scoreRule("政治","X01").fullMark)
        val a=Attempt("1","英语二","Y2015","2026-11-01",true,80.0,null,ScoreParts(60.0,45.0,40.0,35.0).encode(),"")
        assertEquals(45.0,a.reportedScore()!!,0.0)
        val rows=currentResults(listOf(Paper("英语二","Y2015","2015"),Paper("英语二","Y2016","2016"),Paper("政治","Y2015","bad","不适用")),listOf(a,a.copy(id="2",paperKey="Y2016",modules="",score=80.0)))
        assertEquals(listOf(60.0,100.0),rows.map{it.max})
        assertEquals(77.5,rows.map{it.value/it.max*100}.average(),0.001)
    }
    @Test fun seedingHasExactlyRequestedPoliticsEntries() {
        val politics=seededPapers().filter{it.subject=="政治"}
        assertEquals(13,politics.size)
        assertEquals((2022..2026).map{"Y$it"}.toSet(),politics.filter{it.kind=="真题"}.map{it.paperKey}.toSet())
        assertEquals((1..8).map{"肖$it"}.toSet(),politics.filter{it.kind!="真题"}.map{it.title}.toSet())
    }
    @Test fun apiNormalizesEndpointsAndRejectsUnsafeAddresses() {
        assertEquals("https://api.deepseek.com/chat/completions",AiClient.endpoint("https://api.deepseek.com/").toString())
        assertEquals("https://example.com/v1/chat/completions",AiClient.endpoint("https://example.com/v1/chat/completions").toString())
        listOf("http://example.com","https://key@example.com","https://example.com?key=secret").forEach{assertTrue(runCatching{AiClient.endpoint(it)}.isFailure)}
    }
    @Test fun multimodalPayloadIncludesAllImagesAndDoesNotExposeKey() {
        val c=AiConfig(key="test-key");val body=AiClient.payload(c,"本卷笔记",listOf("图1" to "data:image/jpeg;base64,aaa","图2" to "data:image/png;base64,bbb"),AiAnalyzer.instruction("政治"))
        assertFalse(body.toString().contains("test-key"))
        assertEquals(5,body.getJSONArray("messages").getJSONObject(1).getJSONArray("content").length())
        assertTrue(body.toString().contains("多选"))
    }
    private class Fake(val code:Int=200,val response:String="""{"choices":[{"message":{"content":"分析结果"}}]}"""):HttpURLConnection(URL("https://example.com")) {
        val out=ByteArrayOutputStream();var closed=false
        override fun connect(){};override fun disconnect(){closed=true};override fun usingProxy()=false
        override fun getOutputStream()=out
        override fun getResponseCode()=code
        override fun getInputStream()=ByteArrayInputStream(response.toByteArray())
    }
    @Test fun transportSendsBearerAndReturnsResponseWithoutRedirects()=runBlocking {
        val f=Fake();val c=AiConfig(key="test-key")
        assertEquals("分析结果",AiClient.complete(c,AiClient.payload(c,"data",emptyList(),"coach")){f})
        assertEquals("Bearer test-key",f.getRequestProperty("Authorization"))
        assertFalse(f.instanceFollowRedirects);assertTrue(f.closed)
        assertEquals("data",JSONObject(f.out.toString()).getJSONArray("messages").getJSONObject(1).getString("content"))
    }
    @Test fun authAndUnsupportedVisionErrorsAreActionableAndRedacted()=runBlocking {
        val c=AiConfig(key="secret-key")
        for(code in listOf(401,400,429,302)) {
            val f=Fake(code);val e=runCatching{AiClient.complete(c,AiClient.payload(c,"data",emptyList(),"coach")){f}}.exceptionOrNull()
            assertNotNull(e);assertTrue(e!!.message!!.contains(code.toString()));assertFalse(e.message!!.contains(c.key));assertTrue(f.closed)
        }
    }
}
