/** 中文学习注释版｜自动化验证：用固定日期验证倒计时的三种情况。 */
package cn.yantu.records

import java.time.LocalDate
import org.junit.Assert.assertEquals
import org.junit.Test

class CountdownTest {
    private val target=LocalDate.of(2026,12,19)
    @Test fun dayBefore() {assertEquals("1 天",countdownText(target.minusDays(1),target))}
    @Test fun targetDay() {assertEquals("就是今天",countdownText(target,target))}
    @Test fun dayAfter() {assertEquals("目标日期已过",countdownText(target.plusDays(1),target))}
}
