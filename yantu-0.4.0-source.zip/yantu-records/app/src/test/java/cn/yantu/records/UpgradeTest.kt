/** 中文学习注释版｜自动化验证：用模拟 Android 环境验证旧数据保留、图片与备份恢复。 */
package cn.yantu.records

import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.annotation.Config
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.flow.first
import android.net.Uri
import java.io.File

@RunWith(RobolectricTestRunner::class)
@Config(sdk=[28])
class UpgradeTest {
    @Test fun addingPoliticsPreservesDatabaseRecordsAndImages()=runBlocking {
        val context=RuntimeEnvironment.getApplication()
        context.deleteDatabase("records.db")
        val old=RecordsDb(context)
        val paper=Paper("数学二","Y2026","我的自定义标题")
        old.dao().putPaper(paper)
        val attempt=Attempt("old-id","数学二","Y2026","2026-11-20",true,128.0,150,"old-modules","老笔记")
        old.dao().putAttempt(attempt)
        old.dao().putAttachment(Attachment("img1","old-id","keep.jpg","图片说明",3,90))
        old.dao().putDraft(Draft("old-id","未保存草稿"))
        val image=File(context.filesDir,"images/keep.jpg").apply{parentFile!!.mkdirs();writeBytes(byteArrayOf(1,2,3,4))}
        old.close()
        val upgraded=RecordsDb(context)
        upgraded.seedMissingPapers();upgraded.seedMissingPapers()
        assertEquals(paper,upgraded.dao().allPapers().first{it.subject==paper.subject && it.paperKey==paper.paperKey})
        assertEquals(attempt,upgraded.dao().allAttempts().single())
        assertEquals(90,upgraded.dao().allAttachments().single().rotation)
        assertEquals("未保存草稿",upgraded.dao().draft("old-id").first()!!.content)
        assertArrayEquals(byteArrayOf(1,2,3,4),image.readBytes())
        assertEquals(13,upgraded.dao().allPapers().count{it.subject=="政治"})
        assertEquals(95,upgraded.dao().allPapers().size)
        upgraded.close()
    }
    @Test fun zipRoundTripPreservesOldAndNewScoresImagesDraftsAndAiReports()=runBlocking {
        val c=RuntimeEnvironment.getApplication();c.deleteDatabase("records.db")
        val db=RecordsDb(c);db.seedMissingPapers()
        val old=Attempt("old","英语二","Y2015","2026-11-20",true,45.0,null,ScoreParts(60.0,45.0,0.0,0.0).encode(),"英语笔记")
        val political=Attempt("politics","政治","X01","2026-11-21",true,40.0,60,PoliticsParts(16,14,17,13).encode(),"多选漏选")
        db.dao().putAttempt(old);db.dao().putAttempt(political)
        db.dao().putAttachment(Attachment("a","old","test.jpg","保留图片"))
        File(c.filesDir,"images/test.jpg").apply{parentFile!!.mkdirs();writeBytes(byteArrayOf(7,8,9))}
        db.dao().putDraft(Draft("politics","政治草稿"))
        AiReports.save(c,"政治","X01","本卷政治分析");AiReports.save(c,"数学二",null,"数学汇总")
        val f=File(c.cacheDir,"round-trip.zip")
        Backup.export(c,db,Uri.fromFile(f),"2026-12-19",false)
        db.replaceAll(emptyList(),emptyList(),emptyList())
        assertEquals(2,Backup.restore(c,db,Uri.fromFile(f)))
        assertEquals(setOf(old,political),db.dao().allAttempts().toSet())
        assertEquals("政治草稿",db.dao().allDrafts().single().content)
        assertEquals("本卷政治分析",AiReports.read(c,"政治","X01"))
        assertEquals("数学汇总",AiReports.read(c,"数学二",null))
        assertEquals("",AiReports.read(c,"英语二","X01"))
        assertArrayEquals(byteArrayOf(7,8,9),File(c.filesDir,"images/test.jpg").readBytes())
        db.close()
    }
    @Test fun oldVersionOneZipRestoresThenSeedsPolitics()=runBlocking {
        val c=RuntimeEnvironment.getApplication();c.deleteDatabase("records.db");val db=RecordsDb(c)
        val f=File(c.cacheDir,"v1.zip")
        java.util.zip.ZipOutputStream(f.outputStream()).use{z->z.putNextEntry(java.util.zip.ZipEntry("records.json"));z.write("""{"version":1,"papers":[{"subject":"408","key":"Y2022","title":"2022年","kind":"真题"}],"attempts":[{"id":"legacy","subject":"408","key":"Y2022","date":"2026-11-01","completed":true,"score":110,"minutes":null,"modules":"","notes":"原有记录"}],"images":[]}""".toByteArray());z.closeEntry()}
        assertEquals(1,Backup.restore(c,db,Uri.fromFile(f)))
        assertEquals(110.0,db.dao().allAttempts().single().score!!,0.0)
        assertEquals(13,db.dao().allPapers().count{it.subject=="政治"});db.close()
    }
}
