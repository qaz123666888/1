/** 中文学习注释版｜自动化验证：验证主客观计分校验、入口数量和旧分项兼容。 */
package cn.yantu.records

import org.junit.Assert.*
import org.junit.Test

class ScorePartsTest {
    @Test fun englishFinalScoreUsesTheEnteredBreakdown() {
        val parts=ScoreParts(60.0,52.5,40.0,32.5)
        assertNull(parts.validate(100))
        assertEquals(85.0,parts.total,0.00001)
        assertEquals(parts,ScoreParts.decode(parts.encode()))
    }
    @Test fun maximaMustMatchTheSubjectFullMark() {
        assertNotNull(ScoreParts(100.0,90.0,40.0,30.0).validate(150))
        assertNull(ScoreParts(100.0,90.0,50.0,30.0).validate(150))
    }
    @Test fun earnedPointsCannotExceedCategoryMaximum() {
        assertNotNull(ScoreParts(90.0,91.0,60.0,50.0).validate(150))
        assertNotNull(ScoreParts(90.0,80.0,60.0,61.0).validate(150))
        assertNull(ScoreParts(90.0,0.0,60.0,0.0).validate(150))
    }
    @Test fun everySubjectHasTheRequestedPaperSlots() {
        val papers=seededPapers()
        assertEquals(30,papers.count{it.subject=="数学二"})
        assertEquals(22,papers.count{it.subject=="英语二"})
        assertEquals(30,papers.count{it.subject=="408"})
        assertEquals(8,papers.count{it.subject=="数学二" && it.paperKey.startsWith("M")})
        assertEquals(8,papers.count{it.subject=="408" && it.paperKey.startsWith("M")})
    }
    @Test fun oldScoreTextDoesNotBecomeAFakeBreakdown() {
        assertNull(ScoreParts.decode("阅读 32 分"))
    }
}
