/**
 * 中文学习注释版｜界面入口与页面切换
 * 打开软件时从 MainActivity.onCreate() 开始执行。
 * 本文件负责首页、试卷列表、试卷详情、设置，以及图片查看等公共组件。
 * 学习顺序：MainActivity → App → Home / PaperList / Settings；成绩编辑再看 RecordEditor.kt。
 * 对照 docs/MODULE_GUIDE.md 阅读。功能逻辑沿用 0.4.0。
 */
package cn.yantu.records

import android.os.Bundle
import android.graphics.BitmapFactory
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.Alignment
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import java.time.*
import java.time.temporal.ChronoUnit
import java.util.UUID
import java.io.File

/**
 * 普通设置使用 DataStore 保存；它存放目标日期和深色模式，成绩另存 SQLite。
 */
val android.content.Context.settings by preferencesDataStore("settings")
val targetKey=stringPreferencesKey("target")
val darkKey=booleanPreferencesKey("dark")
private val subjects=SUBJECTS
private val kinds=listOf("真题","参考资料","自定义练习","不适用")

/**
 * Android 启动入口。创建数据库，后台补齐试卷入口，然后把 App() 设置为界面内容。
 */
class MainActivity:ComponentActivity() {
    private lateinit var db:RecordsDb
    override fun onCreate(savedInstanceState:Bundle?) { super.onCreate(savedInstanceState)
        db=RecordsDb(applicationContext)
        lifecycleScope.launch(Dispatchers.IO) {
            db.seedMissingPapers()
        }
        setContent { App(db) }
    }
}

/**
 * 界面总入口。page 是底部栏目，subject 是科目；paper / attempt 非空时进入更深一层页面。
 * 这些状态变化会触发 Compose 重新执行相关界面函数。
 */
@Composable private fun App(db:RecordsDb) {
    val context=LocalContext.current
    val scope=rememberCoroutineScope()
    val prefs by context.settings.data.collectAsState(initial=emptyPreferences())
    val target=prefs[targetKey] ?: "2026-12-19"
    val dark=prefs[darkKey] ?: false
    var page by remember { mutableStateOf("首页") }
    var subject by remember { mutableStateOf("数学二") }
    var paper by remember { mutableStateOf<Paper?>(null) }
    var attempt by remember { mutableStateOf<Attempt?>(null) }
    var message by remember { mutableStateOf("") }
    /**
     * 按返回键依次退出成绩页、试卷详情、其他栏目，回到首页。
     */
    BackHandler(attempt!=null || paper!=null || page!="首页") {
        when { attempt!=null -> attempt=null; paper!=null -> paper=null; else -> page="首页" }
        message=""
    }
    val accent=when(subject) {"英语二"->Color(0xFF248663);"408"->Color(0xFF7653A5);"政治"->Color(0xFFC36643);else->Color(0xFF356AC3)}
    val palette=if(dark) darkColorScheme(primary=accent) else lightColorScheme(primary=accent,background=Color(0xFFF7F9FC))
    MaterialTheme(colorScheme=palette) {
      /**
       * Scaffold 提供页面骨架：主内容区域、底部导航栏及提示区域。
       */
      Scaffold(bottomBar={ if(paper==null && attempt==null) NavigationBar {
          listOf("首页","真题","统计","设置").forEach { name -> NavigationBarItem(selected=page==name && paper==null, onClick={page=name; paper=null; attempt=null},label={Text(name)},icon={Text(when(name){"首页"->"⌂";"真题"->"▤";"统计"->"▥";else->"⚙"})}) }
      } }, snackbarHost={ SnackbarHost(remember { SnackbarHostState() }) }) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).padding(horizontal=16.dp)) {
            Spacer(Modifier.height(12.dp))
            if(page!="首页" || paper!=null) Text(if(attempt!=null) "最终成绩" else paper?.title ?: "研途记录",style=MaterialTheme.typography.headlineMedium,fontWeight=FontWeight.Bold)
            if(message.isNotBlank()) Text(message,color=MaterialTheme.colorScheme.error)
            Spacer(Modifier.height(12.dp))
            if(attempt!=null) AttemptEditor(db,attempt!!,{attempt=null},{message=it})
            else if(paper!=null) PaperDetail(db,paper!!,{paper=null},{attempt=it},{message=it})
            else when(page) {
                "首页" -> Column(Modifier.verticalScroll(rememberScrollState())) { Home(db,target,{subject=it;page="真题"},{paper=it}) }
                "真题" -> Column { SubjectTabs(subject){subject=it}; PaperList(db,subject){paper=it} }
                "统计" -> Column {SubjectTabs(subject){subject=it}; StatisticsPage(db,subject) }
                else -> Settings(target,dark,onTarget={scope.launch { context.settings.edit { p->p[targetKey]=it } }},onDark={scope.launch {context.settings.edit {p->p[darkKey]=it} }}, db=db, onMessage={message=it})
            }
        }
      }
    }
}

/**
 * 四科切换条。点击只通过 onSelect 回调通知上层，当前选中科目由 App 管理。
 */
@Composable private fun SubjectTabs(current:String,onSelect:(String)->Unit) {
    Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),horizontalArrangement=Arrangement.spacedBy(6.dp)) { subjects.forEach { s -> FilterChip(selected=s==current,onClick={onSelect(s)},label={Text(s,fontSize=14.sp)}) } }
}
/**
 * 可复用的标题与说明卡片。onClick 是调用它的页面传进来的点击操作。
 */
@Composable private fun CardLine(title:String,detail:String,onClick:()->Unit) {
    Card(onClick=onClick,modifier=Modifier.fillMaxWidth().padding(vertical=5.dp),shape=RoundedCornerShape(16.dp)) {
        Column(Modifier.padding(16.dp)) {Text(title,fontWeight=FontWeight.Bold);Text(detail,style=MaterialTheme.typography.bodySmall)}
    }
}
/**
 * 首页：北京时间倒计时、四科完成进度和最近记录。
 * collectAsState() 把数据库的 Flow 转成可用于界面显示的状态。
 */
@Composable private fun Home(db:RecordsDb,target:String,onSubject:(String)->Unit,onPaper:(Paper)->Unit) {
    var now by remember { mutableStateOf(LocalDate.now(ZoneId.of("Asia/Shanghai"))) }
    val lifecycleOwner=LocalLifecycleOwner.current
    /**
     * 进入前台时刷新日期；退出本次界面生命周期时移除观察者。
     */
    DisposableEffect(lifecycleOwner) {
        val observer=LifecycleEventObserver { _,event -> if(event==Lifecycle.Event.ON_RESUME) now=LocalDate.now(ZoneId.of("Asia/Shanghai")) }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }
    /**
     * 界面存在期间每分钟检查一次日期；delay() 会挂起协程，不会让界面线程睡眠。
     */
    LaunchedEffect(Unit) { while(true) { now=LocalDate.now(ZoneId.of("Asia/Shanghai")); delay(60_000) } }
    val date=runCatching { LocalDate.parse(target) }.getOrDefault(LocalDate.of(2026,12,19))
    val days=ChronoUnit.DAYS.between(now,date)
    Box(Modifier.fillMaxWidth().shadow(10.dp,RoundedCornerShape(28.dp)).clip(RoundedCornerShape(28.dp))
        .background(Brush.linearGradient(listOf(Color(0xFF142C62),Color(0xFF435FBA),Color(0xFF7D65C8))))) {
        Box(Modifier.size(170.dp).align(Alignment.TopEnd).offset(x=45.dp,y=(-55).dp).background(Color.White.copy(alpha=0.08f),CircleShape))
        Column(Modifier.padding(24.dp)) {
            Row(verticalAlignment=Alignment.CenterVertically) {
                Box(Modifier.size(42.dp).clip(RoundedCornerShape(12.dp)).background(Color.White.copy(alpha=.18f)),contentAlignment=Alignment.Center) {Text("研",color=Color.White,fontWeight=FontWeight.Bold)}
                Spacer(Modifier.width(10.dp));Text("研途记录",color=Color.White,style=MaterialTheme.typography.titleLarge,fontWeight=FontWeight.Bold)
            }
            Spacer(Modifier.height(22.dp))
            Text("每一套真题，都算数。",color=Color.White.copy(alpha=.86f),style=MaterialTheme.typography.bodyLarge)
            Spacer(Modifier.height(12.dp))
            Text(countdownText(now,date),color=Color.White,style=MaterialTheme.typography.displayMedium,fontWeight=FontWeight.Bold)
            Text(if(days>0) "距离 $target  ·  稳步向前" else if(days==0L) "相信自己的积累，加油！" else "可在设置中修改目标日",color=Color.White.copy(alpha=.86f))
        }
    }
    Spacer(Modifier.height(22.dp));Text("学习进度",style=MaterialTheme.typography.titleMedium,fontWeight=FontWeight.Bold)
    subjects.forEach { s ->
        val papers by db.dao().papers(s).collectAsState(initial=emptyList())
        val attempts by db.dao().subjectAttempts(s).collectAsState(initial=emptyList())
        val valid=papers.filter { it.kind!="不适用" }
        val done=valid.count { p -> attempts.firstOrNull { it.paperKey==p.paperKey }?.reportedScore()!=null }
        CardLine(s,"已记录最终分数 $done / ${valid.size} 套"){onSubject(s)}
    }
    Text("最近记录",style=MaterialTheme.typography.titleMedium,fontWeight=FontWeight.Bold)
    val recent=subjects.flatMap { s -> val a by db.dao().subjectAttempts(s).collectAsState(initial=emptyList()); a }.distinctBy{it.subject to it.paperKey}.sortedByDescending {it.date}.take(3)
    recent.forEach { a -> val ps by db.dao().papers(a.subject).collectAsState(initial=emptyList()); val p=ps.firstOrNull {it.paperKey==a.paperKey}; if(p!=null) CardLine("${a.subject} · ${p.title}","${a.date} · ${a.reportedScore()?.let { "${it}分" } ?: "待评分"}"){onPaper(p)} }
}
/**
 * 按科目读取试卷入口。LazyColumn 只组合当前需要显示的列表项。
 */
@Composable private fun PaperList(db:RecordsDb,subject:String,onPaper:(Paper)->Unit) {
    val papers by db.dao().papers(subject).collectAsState(initial=emptyList())
    LazyColumn { items(papers,key={it.paperKey}) { p ->
        val all by db.dao().attempts(subject,p.paperKey).collectAsState(initial=emptyList())
        val last=all.firstOrNull()
        CardLine(p.title,"${p.kind} · ${last?.reportedScore()?.let{"最终 ${formatScore(it)} / ${scoreRule(subject,p.paperKey).fullMark} 分"} ?: "尚未录入成绩"}"){onPaper(p)}
    } }
}
/**
 * 试卷详情：修改标题和类型，找到已有最终成绩，或创建一条尚未保存的新记录对象。
 */
@Composable private fun PaperDetail(db:RecordsDb,paper:Paper,onBack:()->Unit,onAttempt:(Attempt)->Unit,onMessage:(String)->Unit) {
    val scope=rememberCoroutineScope()
    val attempts by db.dao().attempts(paper.subject,paper.paperKey).collectAsState(initial=null)
    var title by remember(paper.subject,paper.paperKey){mutableStateOf(paper.title)}
    Column(Modifier.verticalScroll(rememberScrollState())) { TextButton(onClick=onBack){Text("← 返回")};Text("${paper.subject} · ${paper.paperKey}")
        OutlinedTextField(value=title,onValueChange={title=it},label={Text("标题 / 模拟考命题")},modifier=Modifier.fillMaxWidth())
        Row { Button(onClick={scope.launch {db.dao().putPaper(paper.copy(title=title.trim().ifBlank{paper.title}));onMessage("标题已保存")}}){Text("保存标题")}
            Spacer(Modifier.width(8.dp))
            var expanded by remember { mutableStateOf(false) }
            Box { OutlinedButton(onClick={expanded=true}){Text(paper.kind)};DropdownMenu(expanded=expanded,onDismissRequest={expanded=false}) {kinds.forEach { k -> DropdownMenuItem(text={Text(k)},onClick={expanded=false;scope.launch {db.dao().putPaper(paper.copy(kind=k,title=title))}}) } } }
        }
        val record=attempts?.firstOrNull()
        /**
         * 为新记录按“科目/试卷键”生成稳定 ID；已有记录优先复用原来的 ID。
         */
        val stableId=remember(paper.subject,paper.paperKey){UUID.nameUUIDFromBytes("${paper.subject}/${paper.paperKey}".toByteArray(Charsets.UTF_8)).toString()}
        Button(enabled=attempts!=null,onClick={onAttempt(record ?: Attempt(stableId,paper.subject,paper.paperKey,LocalDate.now().toString(),false,null,null,"",""))},modifier=Modifier.fillMaxWidth()) {Text(if(attempts==null) "正在加载记录" else if(record==null) "录入最终成绩与复盘" else "查看或修改最终成绩")}
        if(record!=null) CardLine("最终成绩：${record.reportedScore()?.let{formatScore(it)+" 分"} ?: "尚未录入"}","${record.date} · ${record.minutes?.let{"用时 $it 分钟"} ?: "未记录用时"}"){onAttempt(record)}
    }
}
/**
 * 编辑页的转接函数；实际表单实现集中在 RecordEditor.kt。
 */
@Composable private fun AttemptEditor(db:RecordsDb,item:Attempt,onBack:()->Unit,onMessage:(String)->Unit) {
    RecordEditor(db,item,onBack,onMessage)
}
/**
 * 统一的分数输入框：单行标签与单行输入，数字键盘类型为 Decimal。
 */
@Composable fun ScoreInput(value:String,change:(String)->Unit,label:String) {
    OutlinedTextField(value,change,modifier=Modifier.fillMaxWidth().padding(vertical=4.dp),
        label={Text(label,fontSize=13.sp)},singleLine=true,keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Decimal))
}
/**
 * 通用文字输入框，minLines 控制最少显示行数；笔记使用多行输入。
 */
@Composable fun OutL(value:String,change:(String)->Unit,label:String,minLines:Int=1) {
    OutlinedTextField(value,change,modifier=Modifier.fillMaxWidth().padding(vertical=4.dp),
        label={Text(label,fontSize=13.sp)},textStyle=MaterialTheme.typography.bodyMedium,minLines=minLines)
}
/**
 * 显示缩略图、图片说明、顺序和旋转操作；点开后通过手势调整显示缩放。
 * 旋转角度保存在 Attachment 中，原图文件不在这里重写。
 */
@Composable fun ImageRow(context:android.content.Context,img:Attachment,onUpdate:(Attachment)->Unit,onMove:(Int)->Unit,onDelete:()->Unit) {
    var viewing by remember { mutableStateOf(false) }
    if(viewing) {
        val bitmap=remember(img.fileName) { decodeScaled(File(context.filesDir,"images/${img.fileName}"),2400)?.asImageBitmap() }
        var scale by remember {mutableFloatStateOf(1f)}
        AlertDialog(onDismissRequest={viewing=false},confirmButton={TextButton(onClick={viewing=false}){Text("关闭")}},text={
            if(bitmap!=null) Image(bitmap,contentDescription="答题图片",modifier=Modifier.fillMaxWidth().heightIn(max=550.dp).pointerInput(Unit){detectTransformGestures {_,_,zoom,_->scale=(scale*zoom).coerceIn(1f,5f)}}.graphicsLayer(rotationZ=img.rotation.toFloat(),scaleX=scale,scaleY=scale)) else Text("图片无法读取")
        })
    }
    val thumbnail=remember(img.id) { decodeScaled(File(context.filesDir,"images/${img.fileName}"),180)?.asImageBitmap() }
    Column { Text("图片 ${img.position+1} · 旋转 ${img.rotation}°")
        thumbnail?.let { preview -> Image(preview,contentDescription="图片缩略图",modifier=Modifier.height(90.dp).clickable{viewing=true}) }
        Row(Modifier.horizontalScroll(rememberScrollState())) { TextButton(onClick={onMove(-1)}){Text("上移")};TextButton(onClick={onMove(1)}){Text("下移")};TextButton(onClick={onUpdate(img.copy(rotation=(img.rotation+90)%360))}){Text("旋转")};TextButton(onClick=onDelete){Text("删除")}
            TextButton(onClick={viewing=true}){Text("查看")}
        }
        var caption by remember(img.id){mutableStateOf(img.caption)}
        OutL(caption,{caption=it;onUpdate(img.copy(caption=it))},"图片说明")
    }
}
/**
 * 先只读图片宽高，再用采样率解码较小位图，减少大图片占用的内存。
 */
fun decodeScaled(file:File,maxSide:Int):android.graphics.Bitmap? {
    val bounds=BitmapFactory.Options().apply {inJustDecodeBounds=true}
    BitmapFactory.decodeFile(file.absolutePath,bounds)
    var sample=1
    while(maxOf(bounds.outWidth,bounds.outHeight)/sample>maxSide) sample*=2
    return BitmapFactory.decodeFile(file.absolutePath,BitmapFactory.Options().apply {inSampleSize=sample})
}
/**
 * 设置页：修改日期/主题，调用系统文件选择器导出或恢复备份，下方复用 AiSettings()。
 */
@Composable private fun Settings(target:String,dark:Boolean,onTarget:(String)->Unit,onDark:(Boolean)->Unit,db:RecordsDb,onMessage:(String)->Unit) {
    val context=LocalContext.current;val scope=rememberCoroutineScope();var edit by remember(target){mutableStateOf(target)}
    var pendingRestore by remember {mutableStateOf<android.net.Uri?>(null)}
    var restorePreview by remember {mutableStateOf("")}
    val backup=rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/zip")){uri->if(uri!=null) scope.launch {runCatching {Backup.export(context,db,uri,target,dark)}.onSuccess{onMessage("备份已导出")}.onFailure{onMessage("备份失败：${it.message}")}}}
    val restore=rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()){uri->if(uri!=null) scope.launch {runCatching {Backup.preview(context,uri)}.onSuccess{restorePreview=it;pendingRestore=uri}.onFailure{onMessage("无法预览备份：${it.message}")}}}
    val csv=rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/csv")){uri->if(uri!=null) scope.launch {runCatching {Backup.csv(context,db,uri)}.onSuccess{onMessage("成绩 CSV 已导出")}.onFailure{onMessage("导出失败：${it.message}")}}}
    if(pendingRestore!=null) AlertDialog(onDismissRequest={pendingRestore=null},title={Text("恢复备份")},text={Text("备份包含 $restorePreview。确认后会替换当前全部记录和图片。")},confirmButton={TextButton(onClick={val uri=pendingRestore!!;pendingRestore=null;scope.launch {runCatching {Backup.restore(context,db,uri)}.onSuccess{onMessage("已恢复 ${it} 份记录")}.onFailure{onMessage("恢复失败：${it.message}")}}}){Text("确认替换")}},dismissButton={TextButton(onClick={pendingRestore=null}){Text("取消")}})
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()),verticalArrangement=Arrangement.spacedBy(8.dp)) {OutL(edit,{edit=it},"目标日期 YYYY-MM-DD");Button(onClick={if(runCatching {LocalDate.parse(edit)}.isSuccess)onTarget(edit) else onMessage("日期格式不正确")}){Text("保存目标日期")}
        Row(verticalAlignment=Alignment.CenterVertically){Switch(dark,onDark);Text("深色模式")}
        Button(onClick={backup.launch("研途记录备份.zip")}){Text("导出完整备份")}
        OutlinedButton(onClick={csv.launch("研途记录成绩.csv")}){Text("导出 CSV 成绩表")}
        OutlinedButton(onClick={restore.launch(arrayOf("application/zip","application/octet-stream"))}){Text("从备份恢复（替换现有记录）")}
        Text("备份包含图片与记录。恢复前请先导出当前数据。",style=MaterialTheme.typography.bodySmall)
        HorizontalDivider(Modifier.padding(vertical=12.dp))
        AiSettings()
        Spacer(Modifier.height(24.dp))
    }
}
