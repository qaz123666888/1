/**
 * 中文学习注释版｜科目满分、展示口径与政治计分
 * 先看 scoreRule() 判断科目满分，再看 PoliticsParts 如何把答对题数换成分数。
 * reportedScore() 统一处理显示分数，保留早期英语只统计客观题的规则。
 * 对照 docs/MODULE_GUIDE.md 阅读。功能逻辑沿用 0.4.0。
 */
package cn.yantu.records

import org.json.JSONObject

/**
 * 这张卷的满分与是否仅记客观题。注意它按具体试卷确定，英语不同年份的口径不同。
 */
data class ScoreRule(val fullMark:Int, val objectiveOnly:Boolean=false)
/**
 * 选择满分：政治 50；英语 2016 年前的 Y 年份卷 60，其他英语卷 100；数学二与 408 为 150。
 */
fun scoreRule(subject:String,key:String):ScoreRule = when {
    subject=="政治" -> ScoreRule(50,true)
    subject=="英语二" && key.startsWith("Y") && (key.drop(1).toIntOrNull() ?: 9999)<2016 -> ScoreRule(60,true)
    subject=="英语二" -> ScoreRule(100)
    else -> ScoreRule(150)
}
/**
 * Attempt 的扩展函数。展示早期英语时优先用其客观得分，其他情况用保存的总分。
 */
fun Attempt.reportedScore():Double? {
    val rule=scoreRule(subject,paperKey)
    val p=ScoreParts.decode(modules)
    return if(subject=="英语二" && rule.objectiveOnly && p!=null) p.objectiveEarned else score
}
/**
 * 数字展示辅助函数：把 40.0 显示成 40，保留有意义的小数。
 */
fun formatScore(value:Double):String = java.math.BigDecimal.valueOf(value).stripTrailingZeros().toPlainString()

/**
 * 政治保存的是题数与答对题数。单选得分 = singleCorrect，多选得分 = multiCorrect × 2。
 */
data class PoliticsParts(val singleCount:Int,val singleCorrect:Int,val multiCount:Int,val multiCorrect:Int) {
    /**
     * 先由题数推导满分和得分，再由 validate() 检查题量合计必须为 50 分。
     */
    val singleMax get()=singleCount
    val multiMax get()=multiCount*2
    val singleEarned get()=singleCorrect
    val multiEarned get()=multiCorrect*2
    val total get()=singleEarned+multiEarned
    /**
     * 题数须为非负整数，答对数不得超题数；单选题数 + 多选题数 × 2 必须等于 50。
     */
    fun validate():String? = when {
        listOf(singleCount,singleCorrect,multiCount,multiCorrect).any{it<0} -> "题数和答对题数须为非负整数"
        singleCount>50 || multiCount>25 || singleCount+multiCount*2!=50 -> "单选题数 × 1 + 多选题数 × 2 须等于 50 分"
        singleCorrect>singleCount || multiCorrect>multiCount -> "答对题数不能超过该类总题数"
        else -> null
    }
    /**
     * 政治分项 JSON 带 type=politics 标识，和主观/客观分项使用不同的字段。
     */
    fun encode():String=JSONObject().put("type","politics").put("singleCount",singleCount)
        .put("singleCorrect",singleCorrect).put("multiCount",multiCount).put("multiCorrect",multiCorrect).toString()
    companion object {
        /**
         * 恢复政治分项：检查类型标识，再读取四个整数；读不到时返回 null。
         */
        fun decode(s:String):PoliticsParts?=runCatching { val j=JSONObject(s)
            require(j.getString("type")=="politics")
            PoliticsParts(j.getInt("singleCount"),j.getInt("singleCorrect"),j.getInt("multiCount"),j.getInt("multiCorrect"))
        }.getOrNull()
    }
}
