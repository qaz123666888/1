/**
 * 中文学习注释版｜统计汇总与分数折线图
 * currentResults() 负责挑选每卷的一份最终成绩，StatisticsPage() 排布页面。
 * ScoreTrend() 把分数转换为画布坐标，画网格、折线、圆点、标签，并处理点击选择。
 * 对照 docs/MODULE_GUIDE.md 阅读。功能逻辑沿用 0.4.0。
 */
package cn.yantu.records

import android.graphics.Paint
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.roundToInt

/**
 * 画一个点需要的数据：稳定键、显示标题、分数、该点满分，以及对应完整成绩。
 */
data class ChartDatum(val key:String,val title:String,val value:Double,val max:Double,val attempt:Attempt)
/**
 * 同一科目同一卷只挑最新记录；排除不适用试卷和没有分数的记录，再生成图表点。
 */
fun currentResults(papers:List<Paper>,attempts:List<Attempt>):List<ChartDatum> {
    val latest=attempts.groupBy{it.subject to it.paperKey}.mapValues{(_,v)->v.maxWithOrNull(compareBy<Attempt>{it.date}.thenBy{it.id})}
    return papers.filter{it.kind!="不适用"}.sortedBy{it.paperKey}.mapNotNull {p->
        val a=latest[p.subject to p.paperKey] ?: return@mapNotNull null
        val score=a.reportedScore() ?: return@mapNotNull null
        ChartDatum(p.paperKey,p.title,score,scoreRule(p.subject,p.paperKey).fullMark.toDouble(),a)
    }
}

/**
 * 统计页：选择分项、显示折线图与均分、比较四科得分率，并提供本科 AI 汇总入口。
 */
@Composable fun StatisticsPage(db:RecordsDb,subject:String) {
    val papers by db.dao().papers(subject).collectAsState(initial=emptyList())
    val all by db.dao().subjectAttempts(subject).collectAsState(initial=emptyList())
    val results=currentResults(papers,all)
    val valid=papers.count{it.kind!="不适用"}
    var metric by remember(subject){mutableStateOf("总分")}
    /**
     * 总分、客观/主观或政治单选/多选共用同一张图；这里只把当前分项转换成数值序列。
     */
    val series=results.mapNotNull {r->
        val p=ScoreParts.decode(r.attempt.modules);val pp=PoliticsParts.decode(r.attempt.modules)
        val pair=when(metric) {
            "单选" -> pp?.let{it.singleEarned.toDouble() to it.singleMax.toDouble()}
            "多选" -> pp?.let{it.multiEarned.toDouble() to it.multiMax.toDouble()}
            "客观" -> p?.let{it.objectiveEarned to it.objectiveMax}
            "主观" -> p?.takeIf{!scoreRule(subject,r.key).objectiveOnly}?.let{it.subjectiveEarned to it.subjectiveMax}
            else -> r.value to r.max
        } ?: return@mapNotNull null
        r.copy(value=pair.first,max=pair.second)
    }
    LazyColumn(Modifier.fillMaxSize(),verticalArrangement=Arrangement.spacedBy(14.dp),contentPadding=PaddingValues(top=8.dp,bottom=28.dp)) {
        item {Text("已录入 ${results.size} / $valid 套 · ${if(valid==0) "0" else "%.1f".format(results.size*100.0/valid)}%",fontWeight=FontWeight.Bold)
            Text("每卷统计一份最终成绩；不适用入口不计入进度。",style=MaterialTheme.typography.bodySmall)}
        item {Row(Modifier.horizontalScroll(rememberScrollState()),horizontalArrangement=Arrangement.spacedBy(6.dp)) {
            (if(subject=="政治")listOf("总分","单选","多选") else listOf("总分","客观","主观")).forEach {m->FilterChip(metric==m,{metric=m},label={Text(m,fontSize=12.sp)})}
        }}
        item {Text("${metric}趋势",fontWeight=FontWeight.Bold)
            Text("左右滑动查看全部试卷；点击图中位置查看具体分项。",style=MaterialTheme.typography.bodySmall)
            if(subject=="英语二")Text("2005—2015：客观题 / 60；2016 起：总分 / 100。下方均分按满分分别计算。",style=MaterialTheme.typography.bodySmall)
            ScoreTrend(series)
        }
        if(results.isNotEmpty()) item {Card(Modifier.fillMaxWidth()){Column(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(6.dp)) {
            results.groupBy{it.max}.toSortedMap().forEach{(max,rows)->Text("${formatScore(max)} 分制 · 均分 ${"%.1f".format(rows.map{it.value}.average())} · 最高 ${formatScore(rows.maxOf{it.value})}",style=MaterialTheme.typography.bodyMedium)}
            Text("平均得分率 ${"%.1f".format(results.map{it.value/it.max*100}.average())}%",fontWeight=FontWeight.Bold)
        }}}
        item {Text("四科得分率",fontWeight=FontWeight.Bold)}
        items(SUBJECTS,key={"compare-$it"}) {s->
            val ps by db.dao().papers(s).collectAsState(initial=emptyList())
            val entries by db.dao().subjectAttempts(s).collectAsState(initial=emptyList())
            val rs=currentResults(ps,entries)
            Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween) {
                Text(s,style=MaterialTheme.typography.bodyMedium)
                Text(if(rs.isEmpty()) "暂无成绩" else "${"%.1f".format(rs.map{it.value/it.max*100}.average())}% · ${rs.size}套",style=MaterialTheme.typography.bodyMedium)
            }
        }
        item {AnalysisPanel(db,subject)}
        item {Text("各卷最终成绩",fontWeight=FontWeight.Bold)}
        items(results,key={"result-${it.key}"}) {r->Card(Modifier.fillMaxWidth()){Column(Modifier.padding(14.dp)) {
            Text("${r.title} · ${formatScore(r.value)} / ${formatScore(r.max)}",fontWeight=FontWeight.Bold)
            Text("${r.attempt.date} · ${r.attempt.minutes?.let{"用时 $it 分钟"} ?: "未计时"}",style=MaterialTheme.typography.bodySmall)
        }}}
    }
}

/**
 * 绘图组件。selected 记录当前点；横向滚动保证点间距离，避免卷数多时标签挤在一起。
 */
@Composable fun ScoreTrend(points:List<ChartDatum>) {
    var selected by remember(points.map{it.key}){mutableStateOf(points.lastOrNull()?.key)}
    val density=LocalDensity.current
    val primary=MaterialTheme.colorScheme.primary
    val surface=MaterialTheme.colorScheme.surface
    val ink=MaterialTheme.colorScheme.onSurface
    val grid=MaterialTheme.colorScheme.outlineVariant
    if(points.isEmpty()) {Text("录入成绩后显示折线图。",Modifier.padding(vertical=24.dp),style=MaterialTheme.typography.bodyMedium);return}
    /**
     * 点的横向间距还考虑系统字体缩放；画布比屏幕宽时由外层横向滚动显示。
     */
    val step=82f*density.fontScale.coerceAtLeast(1f)
    val width=maxOf(300f,64f+step*(points.size-1)+40f)
    val max=(points.maxOfOrNull{maxOf(it.max,it.value)} ?: 50.0).coerceAtLeast(1.0)
    Column {
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState())) {
            Canvas(Modifier.width(width.dp).height(245.dp).pointerInput(points,step) {
                detectTapGestures {position->val i=((position.x/density.density-52f)/step).roundToInt().coerceIn(0,points.lastIndex);selected=points[i].key}
            }) {
                val left=52.dp.toPx();val top=42.dp.toPx();val bottom=size.height-58.dp.toPx();val plot=bottom-top
                val paint=Paint(Paint.ANTI_ALIAS_FLAG).apply{color=ink.toArgb();textSize=10.sp.toPx();textAlign=Paint.Align.CENTER}
                val small=Paint(Paint.ANTI_ALIAS_FLAG).apply{color=ink.toArgb();textSize=9.sp.toPx();textAlign=Paint.Align.RIGHT}
                val fill=Paint(Paint.ANTI_ALIAS_FLAG).apply{color=surface.toArgb()}
                /**
                 * 横坐标随序号增加；屏幕 y 轴向下，因此分数越大，要从 bottom 减去越多的高度。
                 */
                val positions=points.mapIndexed{i,p->Offset(left+i*step.dp.toPx(),bottom-(p.value/max).toFloat()*plot)}
                for(i in 0..4) {
                    val y=bottom-plot*i/4
                    drawLine(grid,Offset(left-8.dp.toPx(),y),Offset(width.dp.toPx()-18.dp.toPx(),y),1.dp.toPx())
                    drawContext.canvas.nativeCanvas.drawText(formatScore(max*i/4),left-14.dp.toPx(),y+3.dp.toPx(),small)
                }
                /**
                 * 把相邻点两两配对并连线，随后画圆点和数值标签。
                 */
                positions.zipWithNext().forEach{(a,b)->drawLine(primary,a,b,2.dp.toPx())}
                positions.forEachIndexed{i,p->drawCircle(primary,if(selected==points[i].key)5.dp.toPx() else 3.dp.toPx(),p)}
                positions.forEachIndexed {i,p->
                    val value=formatScore(points[i].value)
                    val baseline=p.y-16.dp.toPx()
                    val half=paint.measureText(value)/2+5.dp.toPx()
                    /**
                     * 给分数文字画留白底，再画数字，使标签在折线附近也容易辨认。
                     */
                    val rect=android.graphics.RectF(p.x-half,baseline+paint.fontMetrics.ascent-3.dp.toPx(),p.x+half,baseline+paint.fontMetrics.descent+3.dp.toPx())
                    drawContext.canvas.nativeCanvas.drawRoundRect(rect,5.dp.toPx(),5.dp.toPx(),fill)
                    drawContext.canvas.nativeCanvas.drawText(value,p.x,baseline,paint)
                    val label=when {points[i].key.startsWith("Y")->points[i].key.drop(1);points[i].key.startsWith("X")->"肖${points[i].key.drop(1).toIntOrNull() ?: ""}";else->"模拟${points[i].key.drop(1).toIntOrNull() ?: ""}"}
                    drawContext.canvas.nativeCanvas.drawText(label,p.x,bottom+28.dp.toPx(),paint)
                }
            }
        }
        /**
         * 根据所选键找到完整记录，在图下方显示该卷分数、题型明细、日期和用时。
         */
        val p=points.firstOrNull{it.key==selected} ?: points.last()
        Card(Modifier.fillMaxWidth()) {Column(Modifier.padding(12.dp),verticalArrangement=Arrangement.spacedBy(4.dp)) {
            Text("${p.title} · ${formatScore(p.value)} / ${formatScore(p.max)} 分",style=MaterialTheme.typography.bodyMedium,fontWeight=FontWeight.Bold)
            val a=p.attempt;val parts=ScoreParts.decode(a.modules);val pp=PoliticsParts.decode(a.modules)
            if(pp!=null)Text("单选 ${pp.singleEarned}/${pp.singleMax} · 多选 ${pp.multiEarned}/${pp.multiMax}",style=MaterialTheme.typography.bodySmall)
            else if(parts!=null)Text("客观 ${formatScore(parts.objectiveEarned)}/${formatScore(parts.objectiveMax)}${if(scoreRule(a.subject,a.paperKey).objectiveOnly) "" else " · 主观 ${formatScore(parts.subjectiveEarned)}/${formatScore(parts.subjectiveMax)}"}",style=MaterialTheme.typography.bodySmall)
            Text("${a.date} · ${a.minutes?.let{"$it 分钟"} ?: "未计时"}",style=MaterialTheme.typography.bodySmall)
        }}
    }
}
