/**
 * 中文学习注释版｜主观题与客观题计分
 * 这是较容易入门的纯业务模块：输入四个数，检查是否合法，计算总分，转成 JSON 保存。
 * 它主要用于数学二、英语二、408；政治的题数规则放在 ScoreRule.kt 中。
 * 对照 docs/MODULE_GUIDE.md 阅读。功能逻辑沿用 0.4.0。
 */
package cn.yantu.records

import org.json.JSONObject
import java.math.BigDecimal
import kotlin.math.abs

/** A score is final only when both categories have user-entered maxima and earned points. */
/**
 * 四个分数参数分别是客观满分/得分、主观满分/得分。该对象负责校验、求总分和 JSON 转换。
 */
data class ScoreParts(
    val objectiveMax: Double,
    val objectiveEarned: Double,
    val subjectiveMax: Double,
    val subjectiveEarned: Double
) {
    /**
     * 总分由两类得分相加；BigDecimal.valueOf() 避免常见小数加法显示误差。
     */
    val total: Double get() = BigDecimal.valueOf(objectiveEarned).add(BigDecimal.valueOf(subjectiveEarned)).toDouble()
    /**
     * 返回 null 代表合法，返回文字代表错误原因；调用者决定如何把提示显示出来。
     */
    fun validate(fullMark: Int): String? = when {
        listOf(objectiveMax, objectiveEarned, subjectiveMax, subjectiveEarned).any { !it.isFinite() || it < 0 } -> "各项须为非负数字"
        abs(objectiveMax + subjectiveMax - fullMark) > 0.001 -> "主观与客观满分之和须为 $fullMark 分"
        objectiveEarned > objectiveMax -> "客观题得分不能超过客观题满分"
        subjectiveEarned > subjectiveMax -> "主观题得分不能超过主观题满分"
        else -> null
    }
    /**
     * 对象转成 JSON 字符串，保存进 attempts.modules 字段。
     */
    fun encode(): String = JSONObject()
        .put("objectiveMax", objectiveMax).put("objectiveEarned", objectiveEarned)
        .put("subjectiveMax", subjectiveMax).put("subjectiveEarned", subjectiveEarned).toString()

    companion object {
        /**
         * JSON 转回对象；旧记录缺少合法分项时返回 null，外层仍可保留原来的总分。
         */
        fun decode(value: String): ScoreParts? = runCatching {
            val json = JSONObject(value)
            ScoreParts(json.getDouble("objectiveMax"), json.getDouble("objectiveEarned"),
                json.getDouble("subjectiveMax"), json.getDouble("subjectiveEarned"))
        }.getOrNull()
    }
}
