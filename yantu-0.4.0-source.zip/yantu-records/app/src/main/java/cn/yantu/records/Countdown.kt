/**
 * 中文学习注释版｜倒计时文字
 * 输入今天和目标日期，返回剩余天数、就是今天或目标日期已过。
 * 这个函数不读数据库，也不画界面，适合先尝试阅读和修改。
 * 对照 docs/MODULE_GUIDE.md 阅读。功能逻辑沿用 0.4.0。
 */
package cn.yantu.records

import java.time.LocalDate
import java.time.temporal.ChronoUnit

/**
 * 纯函数：由两个日期计算显示文字。日期从界面传入，测试时可传入固定日期验证。
 */
fun countdownText(today:LocalDate,target:LocalDate):String {
    val days=ChronoUnit.DAYS.between(today,target)
    return when {
        days>0 -> "$days 天"
        days==0L -> "就是今天"
        else -> "目标日期已过"
    }
}
