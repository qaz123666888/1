/**
 * 中文学习注释版｜完整备份、CSV 导出与恢复
 * 完整 ZIP 包含 records.json 和 images 图片文件；CSV 是方便查看的成绩表。
 * 恢复先在临时目录检查文件与关联，再替换数据；数据库事务与文件回退处理相关失败。
 * API 密钥不进入成绩备份；新版仍能读取旧版 version=1 的备份格式。
 * 对照 docs/MODULE_GUIDE.md 阅读。功能逻辑沿用 0.4.0。
 */
package cn.yantu.records

import android.content.Context
import android.net.Uri
import androidx.datastore.preferences.core.edit
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

/**
 * 备份服务：界面选择文件 URI 后，把具体的读写交给这里执行。
 */
object Backup {
    /**
     * 只查看 records.json 中的数量，供恢复确认框显示；不会在预览时替换现有记录。
     */
    suspend fun preview(context:Context,uri:Uri):String=withContext(Dispatchers.IO) {
        var metadata:String?=null
        context.contentResolver.openInputStream(uri)?.use {input->ZipInputStream(input).use {zip->
            while(true){val entry=zip.nextEntry ?: break
                if(entry.name=="records.json") {metadata=zip.readBytes().toString(Charsets.UTF_8);break}
                zip.closeEntry()
            }
        }} ?: error("无法读取文件")
        val json=JSONObject(metadata ?: error("缺少记录清单"));require(json.getInt("version")==1){"备份版本不支持"}
        "${json.getJSONArray("papers").length()} 个入口、${json.getJSONArray("attempts").length()} 份记录、${json.getJSONArray("images").length()} 张图片"
    }
    /**
     * 导出最终成绩 CSV。双引号转义用于保留字段内的逗号、换行和引号；CSV 不包含图片文件。
     */
    suspend fun csv(context:Context,db:RecordsDb,uri:Uri)=withContext(Dispatchers.IO) {
        fun escape(s:String)="\""+s.replace("\"","\"\"")+"\""
        val current=db.dao().allAttempts().groupBy{it.subject to it.paperKey}.values.mapNotNull{it.maxWithOrNull(compareBy<Attempt>{a->a.date}.thenBy{a->a.id})}
        val rows=current.joinToString("\r\n") {a->val p=ScoreParts.decode(a.modules);val pp=PoliticsParts.decode(a.modules)
            listOf(a.subject,a.paperKey,a.date,p?.objectiveMax?.toString() ?: "",p?.objectiveEarned?.toString() ?: "",p?.subjectiveMax?.toString() ?: "",p?.subjectiveEarned?.toString() ?: "",a.reportedScore()?.toString() ?: "",a.minutes?.toString() ?: "",a.notes,pp?.singleCount?.toString() ?: "",pp?.singleCorrect?.toString() ?: "",pp?.multiCount?.toString() ?: "",pp?.multiCorrect?.toString() ?: "",pp?.multiEarned?.toString() ?: "").joinToString(",",transform=::escape)}
        context.contentResolver.openOutputStream(uri)?.bufferedWriter(Charsets.UTF_8)?.use {it.write("\uFEFF科目,试卷,日期,客观题满分,客观题得分,主观题满分,主观题得分,最终总分,用时分钟,复盘笔记,单选总题数,单选答对数,多选总题数,多选答对数,多选得分\r\n$rows") } ?: error("无法写入文件")
    }
    /**
     * 完整导出：把表数据、草稿和报告放进 records.json，再逐个写入 images 图片目录。
     * 版本字段保留为 1；API 密钥不在这里序列化。
     */
    suspend fun export(context:Context,db:RecordsDb,uri:Uri,target:String,dark:Boolean)=withContext(Dispatchers.IO) {
        val papers=db.dao().allPapers();val attempts=db.dao().allAttempts();val images=db.dao().allAttachments();val drafts=db.dao().allDrafts()
        val json=JSONObject().put("version",1).put("target",target).put("dark",dark)
            .put("drafts",JSONArray().apply{drafts.forEach{put(JSONObject().put("attemptId",it.attemptId).put("content",it.content))}})
            .put("aiReports",JSONArray().apply{File(context.filesDir,"ai_reports").listFiles()?.filter{it.extension=="json"}?.forEach{put(JSONObject(it.readText()))}})
            .put("politicsSingle",context.getSharedPreferences("politics_defaults",0).getString("single",""))
            .put("politicsMulti",context.getSharedPreferences("politics_defaults",0).getString("multi",""))
            .put("papers",JSONArray().apply {papers.forEach {put(JSONObject().put("subject",it.subject).put("key",it.paperKey).put("title",it.title).put("kind",it.kind))}})
            .put("attempts",JSONArray().apply {attempts.forEach {put(JSONObject().put("id",it.id).put("subject",it.subject).put("key",it.paperKey).put("date",it.date).put("completed",it.completed).put("score",it.score).put("minutes",it.minutes).put("modules",it.modules).put("notes",it.notes))}})
            .put("images",JSONArray().apply {images.forEach {put(JSONObject().put("id",it.id).put("attemptId",it.attemptId).put("name",it.fileName).put("caption",it.caption).put("position",it.position).put("rotation",it.rotation))}})
        context.contentResolver.openOutputStream(uri)?.use { stream -> ZipOutputStream(stream).use { zip ->
            zip.putNextEntry(ZipEntry("records.json"));zip.write(json.toString().toByteArray(Charsets.UTF_8));zip.closeEntry()
            images.forEach { image -> val f=File(context.filesDir,"images/${image.fileName}");require(f.isFile){"附件缺失：${image.fileName}"}
                zip.putNextEntry(ZipEntry("images/${image.fileName}"));f.inputStream().use { it.copyTo(zip) };zip.closeEntry() }
        }} ?: error("无法写入目标文件")
    }
    /**
     * 完整恢复：临时解包与校验 → 暂存旧目录 → 安装新文件 → 事务替换数据库 → 恢复设置。
     * 若文件替换或数据库事务失败，会尝试把已移动的旧目录放回。
     */
    suspend fun restore(context:Context,db:RecordsDb,uri:Uri):Int=withContext(Dispatchers.IO) {
        val stage=File(context.cacheDir,"restore-${System.nanoTime()}");stage.mkdirs()
        try {
            var total=0L
            context.contentResolver.openInputStream(uri)?.use { input -> ZipInputStream(input).use { zip ->
                while(true) {val entry=zip.nextEntry ?: break
                    /**
                     * 限制压缩包条目路径，并在解压时限制总字节数，避免文件写到预期目录外。
                     */
                    require(entry.name=="records.json" || (entry.name.startsWith("images/") && entry.name.substringAfter("images/").matches(Regex("[a-zA-Z0-9._-]+")))){"无效备份路径"}
                    val file=File(stage,entry.name);file.parentFile?.mkdirs();file.outputStream().use {out -> val buffer=ByteArray(8192);while(true){val n=zip.read(buffer);if(n<0)break;total+=n;require(total<500_000_000){"备份过大"};out.write(buffer,0,n)}};zip.closeEntry()
                }
            }} ?: error("无法读取备份")
            val json=JSONObject(File(stage,"records.json").readText());require(json.getInt("version")==1){"不支持的备份版本"}
            val ps=json.getJSONArray("papers");val asArray=json.getJSONArray("attempts");val pics=json.getJSONArray("images")
            val papers=(0 until ps.length()).map {ps.getJSONObject(it).let {p->Paper(p.getString("subject"),p.getString("key"),p.getString("title"),p.getString("kind"))}}
            val attempts=(0 until asArray.length()).map {asArray.getJSONObject(it).let {a->Attempt(a.getString("id"),a.getString("subject"),a.getString("key"),a.getString("date"),a.getBoolean("completed"),a.optDouble("score").takeIf{!it.isNaN()},a.optInt("minutes").takeIf{!a.isNull("minutes")},a.getString("modules"),a.getString("notes"))}}
            val images=(0 until pics.length()).map {pics.getJSONObject(it).let {a->Attachment(a.getString("id"),a.getString("attemptId"),a.getString("name"),a.optString("caption"),a.getInt("position"),a.getInt("rotation"))}}
            require(papers.all{it.subject in SUBJECTS} && attempts.all {a->papers.any{it.subject==a.subject && it.paperKey==a.paperKey}} && images.all {a->a.fileName.matches(Regex("[a-zA-Z0-9._-]+")) && a.fileName!="." && a.fileName!=".." && attempts.any{it.id==a.attemptId} && File(stage,"images/${a.fileName}").isFile}){"备份关联或附件不完整"}
            /**
             * 旧备份可能没有草稿和 AI 报告；缺少这些可选字段时按空数组处理。
             */
            val draftsJson=json.optJSONArray("drafts") ?: JSONArray()
            val drafts=(0 until draftsJson.length()).map{draftsJson.getJSONObject(it).let{d->Draft(d.getString("attemptId"),d.getString("content"))}}
            val reportJson=json.optJSONArray("aiReports") ?: JSONArray()
            val reports=(0 until reportJson.length()).map{reportJson.getJSONObject(it)}
            require(reports.all{it.getString("subject") in SUBJECTS && it.has("report")}){"AI 复盘数据不完整"}
            val stagedReports=File(stage,"ai_reports").apply{mkdirs()}
            reports.forEach{r->
                val subject=r.getString("subject");val key=r.optString("paperKey").takeIf{it.isNotBlank() && it!="null"}
                val id=java.util.UUID.nameUUIDFromBytes("$subject/${key ?: "all"}".toByteArray()).toString()
                File(stagedReports,"$id.json").writeText(r.toString())
            }
            val dir=File(context.filesDir,"images")
            val reportDir=File(context.filesDir,"ai_reports")
            val old=File(context.cacheDir,"images-old-${System.nanoTime()}")
            val oldReports=File(context.cacheDir,"reports-old-${System.nanoTime()}")
            /**
             * 这些标志记录目录替换到了哪一步，异常时只回退已经发生的动作。
             */
            var movedImages=false;var movedReports=false;var installedImages=false;var installedReports=false
            try {
                if(dir.exists()){require(dir.renameTo(old)){"无法暂存旧图片"};movedImages=true}
                if(reportDir.exists()){require(reportDir.renameTo(oldReports)){"无法暂存旧复盘"};movedReports=true}
                val newImages=File(stage,"images").apply{mkdirs()}
                require(newImages.renameTo(dir)){"无法恢复图片"};installedImages=true
                require(stagedReports.renameTo(reportDir)){"无法恢复复盘"};installedReports=true
                /**
                 * 数据库更新放进事务；图片目录与数据库的协调由外层 try/catch 负责。
                 */
                db.replaceAll(papers,attempts,images,drafts)
            } catch(e:Exception) {
                if(installedImages)dir.deleteRecursively()
                if(installedReports)reportDir.deleteRecursively()
                if(movedImages)old.renameTo(dir)
                if(movedReports)oldReports.renameTo(reportDir)
                throw e
            }
            old.deleteRecursively();oldReports.deleteRecursively()
            context.settings.edit { it[targetKey]=json.optString("target","2026-12-19");it[darkKey]=json.optBoolean("dark",false) }
            context.getSharedPreferences("politics_defaults",0).edit().putString("single",json.optString("politicsSingle","")).putString("multi",json.optString("politicsMulti","")).apply()
            /**
             * 恢复旧版数据后补齐新科目入口，保留恢复出来的旧标题和成绩。
             */
            db.seedMissingPapers()
            attempts.size
        } finally {stage.deleteRecursively()}
    }
}
