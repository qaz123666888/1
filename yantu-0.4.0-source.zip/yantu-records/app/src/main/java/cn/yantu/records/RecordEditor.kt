/**
 * 中文学习注释版｜成绩、笔记与图片编辑
 * 此页把输入框中的字符串转换成成绩对象，校验后写入数据库。
 * 政治使用 PoliticsParts，其他科目使用 ScoreParts；AI 读取前也先调用 saveRecord()。
 * remember 是界面暂存状态，保存成绩、草稿和图片文件才会产生长期记录。
 * 对照 docs/MODULE_GUIDE.md 阅读。功能逻辑沿用 0.4.0。
 */
package cn.yantu.records

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.first
import java.io.File
import java.time.LocalDate
import java.util.UUID

/**
 * 成绩编辑主页面。item 是当前记录，onBack / onMessage 是外层传入的返回和提示操作。
 */
@Composable fun RecordEditor(db:RecordsDb,item:Attempt,onBack:()->Unit,onMessage:(String)->Unit) {
    val context=LocalContext.current;val scope=rememberCoroutineScope()
    /**
     * 把数据库中的分项 JSON 还原为对象，作为输入框的初始值。
     */
    val existing=remember(item.id){ScoreParts.decode(item.modules)}
    val political=remember(item.id){PoliticsParts.decode(item.modules)}
    val rule=scoreRule(item.subject,item.paperKey);val politics=item.subject=="政治"
    val defaults=remember(item.id){context.getSharedPreferences("politics_defaults",0)}
    /**
     * persisted 表示最近一次成功保存的记录；下面的字符串状态表示正在编辑的输入。
     */
    var persisted by remember(item.id){mutableStateOf(item)}
    var date by remember(item.id){mutableStateOf(item.date)}
    var minutes by remember(item.id){mutableStateOf(item.minutes?.toString() ?: "")}
    var objectiveMax by remember(item.id){mutableStateOf(if(rule.objectiveOnly) rule.fullMark.toString() else existing?.objectiveMax?.let(::formatScore) ?: "")}
    var objectiveEarned by remember(item.id){mutableStateOf(existing?.objectiveEarned?.let(::formatScore) ?: if(rule.objectiveOnly) item.score?.let(::formatScore) ?: "" else "")}
    var subjectiveMax by remember(item.id){mutableStateOf(if(rule.objectiveOnly) "0" else existing?.subjectiveMax?.let(::formatScore) ?: "")}
    var subjectiveEarned by remember(item.id){mutableStateOf(if(rule.objectiveOnly) "0" else existing?.subjectiveEarned?.let(::formatScore) ?: "")}
    var singleCount by remember(item.id){mutableStateOf(political?.singleCount?.toString() ?: defaults.getString("single","").orEmpty())}
    var singleCorrect by remember(item.id){mutableStateOf(political?.singleCorrect?.toString() ?: "")}
    var multiCount by remember(item.id){mutableStateOf(political?.multiCount?.toString() ?: defaults.getString("multi","").orEmpty())}
    var multiCorrect by remember(item.id){mutableStateOf(political?.multiCorrect?.toString() ?: "")}
    var notes by remember(item.id){mutableStateOf(item.notes)}
    var saved by remember(item.id){mutableStateOf("未保存")};var deleteConfirm by remember(item.id){mutableStateOf(false)}
    val images by db.dao().attachments(item.id).collectAsState(initial=emptyList())
    val existingDraft by db.dao().draft(item.id).collectAsState(initial=null)
    var draftLoaded by remember(item.id){mutableStateOf(false)}
    /**
     * 进入一份记录时尝试恢复其文字草稿，保留已有正式记录。
     */
    LaunchedEffect(item.id) {
        val draft=db.dao().draft(item.id).first()
        if(notes==item.notes && draft!=null) {notes=draft.content;saved="已恢复草稿"}
        draftLoaded=true
    }
    /**
     * 文字停改约 600 毫秒后保存草稿；这里只自动保存笔记，不会自动提交整张成绩表。
     */
    LaunchedEffect(notes,draftLoaded) {if(draftLoaded && notes!=persisted.notes){saved="草稿保存中";delay(600);db.dao().putDraft(Draft(item.id,notes));saved="草稿已保存"}}
    /**
     * 输入框给出的是字符串。先判断是否完整，再安全转换为 Double 或 Int。
     */
    val entries=if(politics) listOf(singleCount,singleCorrect,multiCount,multiCorrect) else listOf(objectiveMax,objectiveEarned,subjectiveMax,subjectiveEarned)
    val entered=if(politics) singleCorrect.isNotBlank() || multiCorrect.isNotBlank() else if(rule.objectiveOnly) objectiveEarned.isNotBlank() else entries.any{it.isNotBlank()}
    val parts=if(!politics && entries.all{it.isNotBlank()}) entries.map{it.toDoubleOrNull()}.takeIf{it.all{n->n!=null}}?.let{ScoreParts(it[0]!!,it[1]!!,it[2]!!,it[3]!!)} else null
    val pp=if(politics && entries.all{it.isNotBlank()}) entries.map{it.toIntOrNull()}.takeIf{it.all{n->n!=null}}?.let{PoliticsParts(it[0]!!,it[1]!!,it[2]!!,it[3]!!)} else null
    val score=if(politics) pp?.takeIf{it.validate()==null}?.total?.toDouble() else parts?.takeIf{it.validate(rule.fullMark)==null}?.total
    val finalScore=score ?: if(!entered) persisted.reportedScore() else null
    /**
     * 统一保存出口：检查日期、分项与用时；不合法时提示并返回 null。
     * 合法时编码分项、写入成绩、清掉草稿；政治还会记住最近一次有效题量。
     */
    suspend fun saveRecord():Attempt? {
        val m=minutes.toIntOrNull()
        val error=when {
            runCatching{LocalDate.parse(date)}.isFailure -> "日期格式须为 YYYY-MM-DD"
            entered && politics && pp==null -> "请完整填写四项整数题数"
            entered && politics -> pp?.validate()
            entered && parts==null -> "请完整填写满分和得分"
            entered -> parts?.validate(rule.fullMark)
            else -> null
        } ?: if(minutes.isNotBlank() && (m==null || m<0)) "用时须为非负整数" else null
        if(error!=null){onMessage(error);return null}
        /**
         * copy() 生成修改后的数据对象；putAttempt() 把它写进 SQLite，界面状态也同步更新。
         */
        val updated=persisted.copy(date=date,completed=finalScore!=null,score=finalScore,minutes=m,modules=if(politics) pp?.encode() ?: persisted.modules else parts?.encode() ?: persisted.modules,notes=notes)
        db.dao().putAttempt(updated);db.dao().deleteDraft(item.id);persisted=updated;saved="已保存"
        if(pp!=null && pp.validate()==null) defaults.edit().putString("single",singleCount).putString("multi",multiCount).apply()
        return updated
    }
    /**
     * 系统图片选择器回调：先保存父记录，再把所选图片复制进应用目录并写入图片索引。
     */
    val picker=rememberLauncherForActivityResult(ActivityResultContracts.PickMultipleVisualMedia()) {uris->scope.launch {
        try {
            val parent=saveRecord() ?: return@launch
            withContext(Dispatchers.IO) {
                uris.forEachIndexed {i,uri->
                    val id=UUID.randomUUID().toString();val name="$id.jpg";val f=File(context.filesDir,"images/$name");f.parentFile?.mkdirs()
                    try {
                        context.contentResolver.openInputStream(uri)?.use{input->f.outputStream().use{input.copyTo(it)}} ?: error("无法读取图片")
                        val thumbnail=decodeScaled(f,180) ?: error("图片格式无法读取");thumbnail.recycle()
                        db.dao().putAttachment(Attachment(id,parent.id,name,position=(images.maxOfOrNull{it.position} ?: -1)+1+i))
                    }catch(e:Exception){f.delete();throw e}
                }
            };onMessage("图片已保存")
        }catch(e:Exception){onMessage("图片导入失败：${e.message}")}
    }}
    /**
     * 用户点删除后先显示确认框，确认才删除成绩、相关图片文件和草稿。
     */
    if(deleteConfirm)AlertDialog(onDismissRequest={deleteConfirm=false},title={Text("删除这份记录？")},text={Text("该卷分数、笔记和图片都会删除。")},confirmButton={TextButton(onClick={deleteConfirm=false;scope.launch{db.dao().deleteAttempt(item.id);db.dao().deleteDraft(item.id);images.forEach{File(context.filesDir,"images/${it.fileName}").delete()};onBack()}}){Text("删除")}},dismissButton={TextButton(onClick={deleteConfirm=false}){Text("取消")}})
    /**
     * 下面才是页面布局：日期 → 题型分项 → 总分 → 用时 → 笔记 → 图片 → 保存 → AI 复盘。
     */
    LazyColumn(Modifier.fillMaxSize(),verticalArrangement=Arrangement.spacedBy(12.dp),contentPadding=PaddingValues(bottom=28.dp)) {
        item {TextButton(onClick=onBack){Text("← 返回 ${item.subject}")};Text("${item.paperKey} · ${item.subject}",style=MaterialTheme.typography.bodyMedium)}
        item {OutL(date,{date=it},"做题日期 YYYY-MM-DD")}
        item {Text("${if(politics) "只统计选择题" else if(rule.objectiveOnly) "只统计客观题" else "最终成绩"} · 满分 ${rule.fullMark} 分",fontWeight=FontWeight.Bold)}
        if(politics) {
            item {Text("单选每题 1 分，多选每题 2 分；两类题量由你设置。保存后沿用到下一份政治试卷。",style=MaterialTheme.typography.bodySmall)}
            item {Text("单选",fontWeight=FontWeight.Bold);ScoreInput(singleCount,{singleCount=it},"单选总题数（每题 1 分）");ScoreInput(singleCorrect,{singleCorrect=it},"单选答对题数")}
            item {Text("多选",fontWeight=FontWeight.Bold);ScoreInput(multiCount,{multiCount=it},"多选总题数（每题 2 分）");ScoreInput(multiCorrect,{multiCorrect=it},"多选答对题数")}
            item {Text("当前满分设置：${singleCount.toIntOrNull() ?: 0} + ${(multiCount.toIntOrNull() ?: 0).toLong()*2} / 50 分；已得分：单选 ${pp?.singleEarned ?: "—"}，多选 ${pp?.multiEarned ?: "—"}",style=MaterialTheme.typography.bodySmall)}
        } else {
            item {Text("客观题",fontWeight=FontWeight.Bold);if(!rule.objectiveOnly)ScoreInput(objectiveMax,{objectiveMax=it},"客观题满分");ScoreInput(objectiveEarned,{objectiveEarned=it},"客观题得分")}
            if(!rule.objectiveOnly)item {Text("主观题",fontWeight=FontWeight.Bold);ScoreInput(subjectiveMax,{subjectiveMax=it},"主观题满分");ScoreInput(subjectiveEarned,{subjectiveEarned=it},"主观题得分")}
        }
        item {Card(colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.primaryContainer)){Column(Modifier.fillMaxWidth().padding(16.dp)){Text("最终总分",style=MaterialTheme.typography.labelLarge);Text("${finalScore?.let(::formatScore) ?: "—"} / ${rule.fullMark}",style=MaterialTheme.typography.headlineMedium,fontWeight=FontWeight.Bold)}}}
        item {OutL(minutes,{minutes=it},"用时（分钟，可留空）")}
        item {Text("复盘笔记 · $saved",style=MaterialTheme.typography.labelLarge);Text("可写错题原因、薄弱知识点和下次注意事项，也可粘贴试卷文字。",style=MaterialTheme.typography.bodySmall);OutL(notes,{notes=it},"复盘文字",minLines=5)}
        item {Button(onClick={picker.launch(androidx.activity.result.PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))},modifier=Modifier.fillMaxWidth()){Text("导入作答 / 试卷图片")}}
        items(images,key={it.id}) {img->ImageRow(context,img,onUpdate={scope.launch{db.dao().putAttachment(it)}},onMove={direction->scope.launch{val index=images.indexOfFirst{it.id==img.id};images.getOrNull(index+direction)?.let{db.moveAttachments(img,it)}}},onDelete={scope.launch{db.dao().deleteAttachment(img.id);File(context.filesDir,"images/${img.fileName}").delete()}})}
        item {Button(onClick={scope.launch{if(saveRecord()!=null)onMessage("最终成绩与记录已保存")}},modifier=Modifier.fillMaxWidth()){Text("保存最终成绩与记录")}}
        item {AnalysisPanel(db,item.subject,item.paperKey,snapshot={saveRecord()})}
        item {TextButton(onClick={deleteConfirm=true}){Text("删除这份记录")}}
    }
}
