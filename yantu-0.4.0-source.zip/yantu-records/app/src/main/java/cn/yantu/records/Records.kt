/**
 * 中文学习注释版｜数据模型与本地数据库
 * 先读 Paper、Attempt、Attachment、Draft 四种数据，再读 RecordsDb 和 RecordDao。
 * SQLite 保存长期记录；Flow 发出变更通知，让 Compose 重新查询并显示数据。
 * 按科目隔离主要依靠 subject 与 paperKey，数据库初始化只补齐缺失的试卷入口。
 * 对照 docs/MODULE_GUIDE.md 阅读。功能逻辑沿用 0.4.0。
 */
package cn.yantu.records

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.withContext

// Keep the Room v1 table and column names so an existing installation can open its database.
/**
 * 试卷入口：subject 是科目，paperKey 是稳定键（如 Y2026、X01），title 是可修改标题。
 */
data class Paper(
    /** 科目名称 */
    val subject:String,
    /** 稳定试卷键 */
    val paperKey:String,
    /** 界面标题 */
    val title:String,
    /** 真题/自定义练习等类型 */
    val kind:String="真题"
)
/**
 * 最终成绩记录：score 可为空表示尚无最终分数；modules 保存分项 JSON，notes 保存复盘文字。
 */
data class Attempt(
    /** 这条记录的唯一 ID */
    val id:String,
    /** 所属科目 */
    val subject:String,
    /** 所属试卷键 */
    val paperKey:String,
    /** 做题日期字符串 */
    val date:String,
    /** 是否已有最终成绩 */
    val completed:Boolean,
    /** 最终总分，可为空 */
    val score:Double?,
    /** 用时分钟，可为空 */
    val minutes:Int?,
    /** 题型分项 JSON */
    val modules:String,
    /** 复盘笔记 */
    val notes:String
)
/**
 * 图片索引：数据库记录文件名、所属记录、说明、排序和旋转；图片字节另放 files/images。
 */
data class Attachment(
    /** 图片索引 ID */
    val id:String,
    /** 所属成绩记录 ID */
    val attemptId:String,
    /** 应用图片目录内的文件名 */
    val fileName:String,
    /** 图片说明 */
    val caption:String="",
    /** 排序位置 */
    val position:Int=0,
    /** 显示旋转角度 */
    val rotation:Int=0
)
/**
 * 笔记草稿：用 attemptId 找到对应编辑记录，content 是尚未正式保存的文字。
 */
data class Draft(
    /** 对应记录 ID */
    val attemptId:String,
    /** 草稿文字 */
    val content:String
)

/**
 * SQLiteOpenHelper 管理 records.db 的创建和连接。当前数据库版本为 1。
 * RecordDao 是本项目手写的数据访问封装，界面通过 db.dao() 调用它。
 */
class RecordsDb(context:Context):SQLiteOpenHelper(context,"records.db",null,1) {
    /**
     * 变化计数器。它通知订阅者重新查库；计数器本身不保存成绩。
     */
    private val changed=MutableStateFlow(0)
    val dao=RecordDao()
    /**
     * 把数据访问对象交给界面、备份和 AI 模块使用。
     */
    fun dao():RecordDao=dao
    /**
     * 启用外键约束，让图片能关联到成绩记录，成绩能关联到试卷入口。
     */
    override fun onConfigure(db:SQLiteDatabase) { db.setForeignKeyConstraintsEnabled(true) }
    /**
     * 首次创建四张表和相关索引。CREATE TABLE 中的字段对应上面的四种 data class。
     */
    override fun onCreate(db:SQLiteDatabase) {
        db.execSQL("CREATE TABLE IF NOT EXISTS papers (subject TEXT NOT NULL, paperKey TEXT NOT NULL, title TEXT NOT NULL, kind TEXT NOT NULL, PRIMARY KEY(subject,paperKey))")
        db.execSQL("CREATE TABLE IF NOT EXISTS attempts (id TEXT NOT NULL PRIMARY KEY, subject TEXT NOT NULL, paperKey TEXT NOT NULL, date TEXT NOT NULL, completed INTEGER NOT NULL, score REAL, minutes INTEGER, modules TEXT NOT NULL, notes TEXT NOT NULL, FOREIGN KEY(subject,paperKey) REFERENCES papers(subject,paperKey) ON DELETE CASCADE)")
        db.execSQL("CREATE INDEX IF NOT EXISTS index_attempts_subject_paperKey ON attempts(subject,paperKey)")
        db.execSQL("CREATE TABLE IF NOT EXISTS attachments (id TEXT NOT NULL PRIMARY KEY, attemptId TEXT NOT NULL, fileName TEXT NOT NULL, caption TEXT NOT NULL, position INTEGER NOT NULL, rotation INTEGER NOT NULL, FOREIGN KEY(attemptId) REFERENCES attempts(id) ON DELETE CASCADE)")
        db.execSQL("CREATE INDEX IF NOT EXISTS index_attachments_attemptId ON attachments(attemptId)")
        db.execSQL("CREATE TABLE IF NOT EXISTS drafts (attemptId TEXT NOT NULL PRIMARY KEY, content TEXT NOT NULL)")
    }
    /**
     * 以后调整表结构时，需要在这里写清楚数据迁移步骤；当前代码遇到未知升级会报错。
     */
    override fun onUpgrade(db:SQLiteDatabase,oldVersion:Int,newVersion:Int) { error("数据库需要显式升级迁移，原数据未被删除") }
    /**
     * 写入成功后递增计数器，使 Flow 的订阅者重新获取数据。
     */
    private fun notifyChange(){changed.update{it+1}}
    /**
     * 把“字段名 to 值”转换成 SQLite insert / update 需要的 ContentValues。
     */
    private fun values(vararg pairs:Pair<String,Any?>)=ContentValues().apply { pairs.forEach {(k,v)-> when(v){null->putNull(k);is String->put(k,v);is Int->put(k,v);is Double->put(k,v);is Boolean->put(k,if(v)1 else 0)} } }
    /**
     * 下面四个 Cursor 扩展函数按列名读值；optD / optI 保留数据库 NULL。
     */
    private fun Cursor.s(name:String)=getString(getColumnIndexOrThrow(name))
    private fun Cursor.i(name:String)=getInt(getColumnIndexOrThrow(name))
    private fun Cursor.optD(name:String)=getColumnIndexOrThrow(name).let{if(isNull(it))null else getDouble(it)}
    private fun Cursor.optI(name:String)=getColumnIndexOrThrow(name).let{if(isNull(it))null else getInt(it)}
    /**
     * 通用查询：执行带参数 SQL，遍历 Cursor，用传入的 row 函数生成数据对象；use 会关闭 Cursor。
     */
    private fun <T> query(sql:String,args:Array<String> = emptyArray(),row:(Cursor)->T):List<T> = readableDatabase.rawQuery(sql,args).use { c-> buildList{while(c.moveToNext())add(row(c))} }
    /**
     * 读取当前试卷快照。subject 为 null 时读所有科目，否则使用占位参数筛选。
     */
    private fun papersNow(subject:String?=null)=query("SELECT * FROM papers ${if(subject!=null)"WHERE subject=?" else ""} ORDER BY subject,paperKey DESC",if(subject!=null)arrayOf(subject) else emptyArray()){Paper(it.s("subject"),it.s("paperKey"),it.s("title"),it.s("kind"))}
    /**
     * 按科目与试卷筛选记录，并按日期和 ID 倒序排列，让最近一条排在前面。
     */
    private fun attemptsNow(subject:String?=null,key:String?=null)=query("SELECT * FROM attempts ${if(subject==null)"" else if(key==null)"WHERE subject=?" else "WHERE subject=? AND paperKey=?"} ORDER BY date DESC,id DESC",if(subject==null)emptyArray() else if(key==null)arrayOf(subject) else arrayOf(subject,key)){Attempt(it.s("id"),it.s("subject"),it.s("paperKey"),it.s("date"),it.i("completed")!=0,it.optD("score"),it.optI("minutes"),it.s("modules"),it.s("notes"))}
    /**
     * 读取图片索引，按 position 和 ID 排序；这里不会读取图片文件内容。
     */
    private fun attachmentsNow(id:String?=null)=query("SELECT * FROM attachments ${if(id!=null)"WHERE attemptId=?" else ""} ORDER BY position,id",if(id!=null)arrayOf(id) else emptyArray()){Attachment(it.s("id"),it.s("attemptId"),it.s("fileName"),it.s("caption"),it.i("position"),it.i("rotation"))}
    /**
     * DAO（数据访问对象）：集中提供查询、写入、删除等方法。
     */
    inner class RecordDao {
        /**
         * 持续观察某科目试卷。数据库有变动时重新查询，查询运行在线程池的 IO 上下文。
         */
        fun papers(subject:String):Flow<List<Paper>> = changed.map{papersNow(subject)}.flowOn(Dispatchers.IO)
        /**
         * 持续观察某一科目某一卷的成绩。
         */
        fun attempts(subject:String,key:String):Flow<List<Attempt>> = changed.map{attemptsNow(subject,key)}.flowOn(Dispatchers.IO)
        /**
         * 持续观察某科目全部成绩，首页和统计页都会使用。
         */
        fun subjectAttempts(subject:String):Flow<List<Attempt>> = changed.map{attemptsNow(subject)}.flowOn(Dispatchers.IO)
        /**
         * 持续观察一份成绩下的图片索引。
         */
        fun attachments(id:String):Flow<List<Attachment>> = changed.map{attachmentsNow(id)}.flowOn(Dispatchers.IO)
        /**
         * 读取并观察一份记录的笔记草稿；找不到时返回 null。
         */
        fun draft(id:String):Flow<Draft?> = changed.map{query("SELECT * FROM drafts WHERE attemptId=?",arrayOf(id)){Draft(it.s("attemptId"),it.s("content"))}.firstOrNull()}.flowOn(Dispatchers.IO)
        /**
         * 以下 all... 方法只读取一次快照，主要供备份、恢复和 AI 整理资料使用。
         */
        suspend fun allDrafts()=withContext(Dispatchers.IO){query("SELECT * FROM drafts"){Draft(it.s("attemptId"),it.s("content"))}}
        suspend fun allPapers()=withContext(Dispatchers.IO){papersNow()}
        suspend fun allAttempts()=withContext(Dispatchers.IO){attemptsNow()}
        suspend fun allAttachments()=withContext(Dispatchers.IO){attachmentsNow()}
        /**
         * 先按科目与试卷键更新；不存在时再插入，避免把关联记录一起替换。
         */
        suspend fun putPaper(p:Paper)=withContext(Dispatchers.IO){
            val v=values("title" to p.title,"kind" to p.kind)
            if(writableDatabase.update("papers",v,"subject=? AND paperKey=?",arrayOf(p.subject,p.paperKey))==0)
                writableDatabase.insertOrThrow("papers",null,values("subject" to p.subject,"paperKey" to p.paperKey,"title" to p.title,"kind" to p.kind))
            notifyChange()
        }
        /**
         * 按记录 ID 更新最终成绩；新 ID 则插入。写完通知正在显示该数据的界面。
         */
        suspend fun putAttempt(a:Attempt)=withContext(Dispatchers.IO){
            val v=values("subject" to a.subject,"paperKey" to a.paperKey,"date" to a.date,"completed" to a.completed,"score" to a.score,"minutes" to a.minutes,"modules" to a.modules,"notes" to a.notes)
            if(writableDatabase.update("attempts",v,"id=?",arrayOf(a.id))==0) {v.put("id",a.id);writableDatabase.insertOrThrow("attempts",null,v)}
            notifyChange()
        }
        /**
         * 保存图片索引。调用前应先建立父成绩记录，以满足外键约束。
         */
        suspend fun putAttachment(a:Attachment)=withContext(Dispatchers.IO){
            val v=values("attemptId" to a.attemptId,"fileName" to a.fileName,"caption" to a.caption,"position" to a.position,"rotation" to a.rotation)
            if(writableDatabase.update("attachments",v,"id=?",arrayOf(a.id))==0){v.put("id",a.id);writableDatabase.insertOrThrow("attachments",null,v)}
            notifyChange()
        }
        /**
         * 保存同一 attemptId 的最新笔记草稿。
         */
        suspend fun putDraft(d:Draft)=withContext(Dispatchers.IO){writableDatabase.insertWithOnConflict("drafts",null,values("attemptId" to d.attemptId,"content" to d.content),SQLiteDatabase.CONFLICT_REPLACE);notifyChange()}
        /**
         * 正式保存完成后清掉相应草稿，避免下次把旧草稿恢复回来。
         */
        suspend fun deleteDraft(id:String)=withContext(Dispatchers.IO){writableDatabase.delete("drafts","attemptId=?",arrayOf(id));notifyChange()}
        /**
         * 删除图片索引；图片文件的删除由调用它的编辑界面负责。
         */
        suspend fun deleteAttachment(id:String)=withContext(Dispatchers.IO){writableDatabase.delete("attachments","id=?",arrayOf(id));notifyChange()}
        /**
         * 删除成绩记录，外键会级联删除其图片索引；实际图片文件由调用者清理。
         */
        suspend fun deleteAttempt(id:String)=withContext(Dispatchers.IO){writableDatabase.delete("attempts","id=?",arrayOf(id));notifyChange()}
    }
    /**
     * 在同一个数据库事务中交换两张图片的 position，避免只完成一半的排序更新。
     */
    suspend fun moveAttachments(first:Attachment,second:Attachment)=withContext(Dispatchers.IO){
        writableDatabase.beginTransaction()
        try {writableDatabase.execSQL("UPDATE attachments SET position=? WHERE id=?",arrayOf<Any>(second.position,first.id));writableDatabase.execSQL("UPDATE attachments SET position=? WHERE id=?",arrayOf<Any>(first.position,second.id));writableDatabase.setTransactionSuccessful()}
        finally {writableDatabase.endTransaction()};notifyChange()
    }
    /**
     * 恢复备份使用的整库替换：在事务中删除旧行、插入新行。
     * 任意一步失败时数据库事务回滚；图片目录的回退由 Backup.restore() 负责。
     */
    suspend fun replaceAll(papers:List<Paper>,attempts:List<Attempt>,attachments:List<Attachment>,drafts:List<Draft> = emptyList())=withContext(Dispatchers.IO){
        val db=writableDatabase;db.beginTransaction()
        try {
            db.delete("drafts",null,null);db.delete("attachments",null,null);db.delete("attempts",null,null);db.delete("papers",null,null)
            papers.forEach{p->db.insertOrThrow("papers",null,values("subject" to p.subject,"paperKey" to p.paperKey,"title" to p.title,"kind" to p.kind))}
            attempts.forEach{a->db.insertOrThrow("attempts",null,values("id" to a.id,"subject" to a.subject,"paperKey" to a.paperKey,"date" to a.date,"completed" to a.completed,"score" to a.score,"minutes" to a.minutes,"modules" to a.modules,"notes" to a.notes))}
            attachments.forEach{a->db.insertOrThrow("attachments",null,values("id" to a.id,"attemptId" to a.attemptId,"fileName" to a.fileName,"caption" to a.caption,"position" to a.position,"rotation" to a.rotation))}
            drafts.forEach{d->db.insertOrThrow("drafts",null,values("attemptId" to d.attemptId,"content" to d.content))}
            db.setTransactionSuccessful()
        } finally {db.endTransaction()};notifyChange()
    }
}

/**
 * 科目统一列表：首页、科目切换、统计、备份校验和初始入口都会引用它。
 */
val SUBJECTS=listOf("数学二","英语二","408","政治")
/**
 * 生成默认入口清单：数学二/408 各 30 套、英语二 22 套、政治 13 套。
 */
fun seededPapers():List<Paper> = SUBJECTS.flatMap { subject ->
    if(subject=="政治") (2026 downTo 2022).map { Paper(subject,"Y$it","${it}年政治真题") } +
        (1..8).map { Paper(subject,"X%02d".format(it),"肖$it","自定义练习") }
    else (2005..2026).map { year -> Paper(subject,"Y$year","${year}年") } +
      (if(subject=="英语二") emptyList() else (1..8).map { n -> Paper(subject,"M%02d".format(n),"模拟考$n","自定义练习") })
}

/** Insert missing entries without replacing user titles or records. */
/**
 * 对比已有“科目 + 试卷键”，只插入缺失入口，保留用户改过的标题、类型及原记录。
 */
suspend fun RecordsDb.seedMissingPapers() {
    val existing=dao().allPapers().map { it.subject to it.paperKey }.toSet()
    seededPapers().filter { (it.subject to it.paperKey) !in existing }.forEach { dao().putPaper(it) }
}
