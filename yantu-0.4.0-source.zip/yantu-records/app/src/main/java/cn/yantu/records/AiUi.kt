/**
 * 中文学习注释版｜AI 设置界面与复盘按钮
 * AiSettings() 显示统一 API 表单；AnalysisPanel() 用于单卷和本科汇总两个位置。
 * 界面负责接收输入和显示状态；具体的资料整理与发送交给 AiClient.kt。
 * 对照 docs/MODULE_GUIDE.md 阅读。功能逻辑沿用 0.4.0。
 */
package cn.yantu.records

import android.graphics.Bitmap
import android.util.Base64
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.*
import java.io.ByteArrayOutputStream

/**
 * 统一设置表单：编辑服务商地址、模型、密钥、图片支持选项；保存与测试分别由按钮触发。
 */
@Composable fun AiSettings() {
    val context=LocalContext.current;val scope=rememberCoroutineScope()
    val initial=remember{AiConfigStore.load(context)}
    var url by remember{mutableStateOf(initial.baseUrl)}
    var model by remember{mutableStateOf(initial.model)}
    var secret by remember{mutableStateOf(initial.key)}
    var vision by remember{mutableStateOf(initial.vision)}
    var status by remember{mutableStateOf("")};var busy by remember{mutableStateOf(false)}
    Text("AI 接口 · 四科共用",style=MaterialTheme.typography.titleMedium,fontWeight=FontWeight.Bold)
    Text("兼容 Chat Completions 的 HTTPS 接口。填写服务商地址、模型名和 API 密钥。",style=MaterialTheme.typography.bodySmall)
    OutL(url,{url=it},"接口基础地址（可含 /v1）")
    OutL(model,{model=it},"模型名称")
    OutlinedTextField(secret,{secret=it},modifier=Modifier.fillMaxWidth(),label={Text("API 密钥")},singleLine=true,visualTransformation=PasswordVisualTransformation())
    Row { Checkbox(vision,{vision=it});Text("模型支持图片输入",Modifier.padding(top=12.dp)) }
    Text("分析时才会将选定科目的文字和所选图片发送给上述服务商，可能产生 API 费用。密钥在本机加密保存，不写入成绩备份。",style=MaterialTheme.typography.bodySmall)
    Button(enabled=!busy,onClick={scope.launch {
        try { withContext(Dispatchers.IO){AiConfigStore.save(context,AiConfig(url,model,secret,vision))};status="AI 设置已保存" }
        catch(e:Exception){status=e.message ?: "保存失败"}
    }},modifier=Modifier.fillMaxWidth()){Text("保存 AI 设置")}
    OutlinedButton(enabled=!busy,onClick={scope.launch {
        busy=true;status="正在测试${if(vision) "文字与图片" else "文字"}连接…"
        try {
            val c=AiConfig(url.trim(),model.trim(),secret.trim(),vision)
            withContext(Dispatchers.IO){AiConfigStore.save(context,c)}
            /**
             * 连接测试使用程序生成的小蓝图，不会拿用户的作答图片来做测试。
             */
            val pics=if(vision) withContext(Dispatchers.IO){
                val bm=Bitmap.createBitmap(32,32,Bitmap.Config.ARGB_8888);bm.eraseColor(android.graphics.Color.BLUE)
                val bytes=ByteArrayOutputStream().use{bm.compress(Bitmap.CompressFormat.PNG,100,it);it.toByteArray()};bm.recycle()
                listOf("用于连接测试的蓝色图片" to "data:image/png;base64,${Base64.encodeToString(bytes,Base64.NO_WRAP)}")
            } else emptyList()
            AiClient.complete(c,AiClient.payload(c,"请只用一句中文确认接口连接成功。",pics,"这是接口连通性测试，请简短回复。"))
            status="连接成功${if(vision) "，接口已接受图片请求" else "（文字模式）"}"
        } catch(e:CancellationException){throw e}
          catch(e:Exception){status=e.message ?: "连接失败，请检查网络和 API 设置"}
        finally {busy=false}
    }},modifier=Modifier.fillMaxWidth()){Text(if(busy) "测试中…" else "测试连接（少量 API 用量）")}
    if(status.isNotBlank())Text(status,style=MaterialTheme.typography.bodySmall)
}

/**
 * 单卷和本科共用的分析面板。paperKey 标记保存范围，snapshot 用于单卷分析前保存当前输入。
 */
@Composable fun AnalysisPanel(db:RecordsDb,subject:String,paperKey:String?=null,snapshot:(suspend ()->Attempt?)?=null) {
    val context=LocalContext.current;val scope=rememberCoroutineScope()
    var includeImages by remember(subject,paperKey){mutableStateOf(AiConfigStore.load(context).vision)}
    var report by remember(subject,paperKey){mutableStateOf(AiReports.read(context,subject,paperKey))}
    var status by remember(subject,paperKey){mutableStateOf("")};var busy by remember(subject,paperKey){mutableStateOf(false)}
    Card(Modifier.fillMaxWidth()) {Column(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(8.dp)) {
        Text("$subject · AI 复盘",fontWeight=FontWeight.Bold)
        Text(if(paperKey==null) "读取本科各卷最终成绩、复盘文字及图片，汇总强化方向。" else "读取本卷当前输入的成绩、文字、图片说明及附件。点击分析时会先保存有效记录。",style=MaterialTheme.typography.bodySmall)
        Row { Checkbox(includeImages,{if(!busy)includeImages=it});Text("同时读取作答图片",Modifier.padding(top=12.dp)) }
        Text("点击后会将上述资料发送给设置中的 API 服务商。未勾选时只分析文字。",style=MaterialTheme.typography.bodySmall)
        Button(enabled=!busy,onClick={scope.launch {
            busy=true;status="正在读取${subject}资料并分析…"
            try {
                /**
                 * 先取得并保存本卷输入快照；有错误会停止，避免分析旧成绩或丢掉当前输入。
                 */
                val item=if(snapshot!=null) snapshot() ?: error("请先修正成绩输入后再分析") else null
                report=AiAnalyzer.analyze(context,db,subject,item,includeImages)
                status="分析完成，结果已保存"
            } catch(e:CancellationException){throw e}
              catch(e:Exception){status=e.message ?: "分析失败，请检查网络或接口设置"}
            finally {busy=false}
        }},modifier=Modifier.fillMaxWidth()){Text(if(busy) "分析中…" else if(paperKey==null) "分析本科全部已录入试卷" else "保存并分析本卷")}
        if(busy)LinearProgressIndicator(Modifier.fillMaxWidth())
        if(status.isNotBlank())Text(status,style=MaterialTheme.typography.bodySmall)
        if(report.isNotBlank())SelectionContainer {Text(report,style=MaterialTheme.typography.bodyMedium)}
    }}
}
