// 根构建文件：声明 Android、Kotlin、Compose 插件版本，app 模块再启用这些插件。
plugins {
    id("com.android.application") version "8.9.2" apply false
    id("org.jetbrains.kotlin.android") version "2.1.20" apply false
    id("org.jetbrains.kotlin.plugin.compose") version "2.1.20" apply false
}
