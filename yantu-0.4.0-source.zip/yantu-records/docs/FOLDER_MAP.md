# 工程文件夹与完整文件索引

## 主要目录

| 目录 | 用途 |
| --- | --- |
| `app/src/main/java/cn/yantu/records/` | 软件业务 Kotlin 源码 |
| `app/src/main/res/` | 图标、颜色等资源 |
| `app/src/test/java/cn/yantu/records/` | 测试源码 |
| `gradle/wrapper/` | 固定版本构建启动器 |
| `signing/` | 本机签名说明，私钥不入库 |
| `release/` | 可直接安装的 APK |
| `docs/` | 中文学习资料和验证记录 |

## 所有交付文件

下表路径相对于解压后的工程根目录。构建缓存和本机 Android SDK 由开发工具管理，不属于业务源码。

| 文件路径 | 内容 |
| --- | --- |
| `README.md` | 原版功能、安装、迁移与构建说明 |
| `START_HERE.md` | 第一轮阅读顺序与完整工程入口 |
| `TEST_REPORT.md` | 原 0.4.0 的测试与模拟器验证记录 |
| `app/build.gradle.kts` | 安装标识、系统版本、签名、依赖与测试配置 |
| `app/src/main/AndroidManifest.xml` | 权限、应用名称、图标与启动页面 |
| `app/src/main/java/cn/yantu/records/AiClient.kt` | 配置加密、网络请求、资料整理和报告保存（已加中文注释） |
| `app/src/main/java/cn/yantu/records/AiUi.kt` | API 设置与分析按钮（已加中文注释） |
| `app/src/main/java/cn/yantu/records/Backup.kt` | CSV / 完整 ZIP 备份与恢复（已加中文注释） |
| `app/src/main/java/cn/yantu/records/Countdown.kt` | 倒计时纯函数（已加中文注释） |
| `app/src/main/java/cn/yantu/records/MainActivity.kt` | 启动、页面导航、首页、公共组件与设置（已加中文注释） |
| `app/src/main/java/cn/yantu/records/RecordEditor.kt` | 成绩、草稿和图片编辑（已加中文注释） |
| `app/src/main/java/cn/yantu/records/Records.kt` | 四种数据对象、SQLite 与数据访问封装（已加中文注释） |
| `app/src/main/java/cn/yantu/records/ScoreParts.kt` | 主客观分项校验与序列化（已加中文注释） |
| `app/src/main/java/cn/yantu/records/ScoreRule.kt` | 科目口径与政治计分（已加中文注释） |
| `app/src/main/java/cn/yantu/records/StatisticsPage.kt` | 汇总、分项趋势和折线图（已加中文注释） |
| `app/src/main/res/drawable/icon_foreground.xml` | 图标前景矢量路径 |
| `app/src/main/res/mipmap-anydpi-v26/ic_launcher.xml` | 自适应桌面图标组合 |
| `app/src/main/res/values/colors.xml` | 颜色资源 |
| `app/src/test/java/cn/yantu/records/CountdownTest.kt` | 对应业务的自动化测试（含中文模块说明） |
| `app/src/test/java/cn/yantu/records/RulesAndAiTest.kt` | 对应业务的自动化测试（含中文模块说明） |
| `app/src/test/java/cn/yantu/records/ScorePartsTest.kt` | 对应业务的自动化测试（含中文模块说明） |
| `app/src/test/java/cn/yantu/records/UpgradeTest.kt` | 对应业务的自动化测试（含中文模块说明） |
| `build.gradle.kts` | 根插件版本 |
| `docs/BUILD_AND_LEARN.md` | 运行步骤与三个小练习 |
| `docs/FOLDER_MAP.md` | 本完整文件索引 |
| `docs/MODULE_GUIDE.md` | 模块职责、业务流程和 Kotlin 入门说明 |
| `docs/STUDY_VERIFICATION.md` | 注释版构建、测试及功能代码一致性核验 |
| `gradle/wrapper/gradle-wrapper.jar` | 启动固定版本 Gradle 的包装器程序 |
| `gradle/wrapper/gradle-wrapper.properties` | 指定 Wrapper 下载的 Gradle 版本 |
| `gradle.properties` | Gradle / AndroidX / Kotlin 全局选项 |
| `gradlew` | macOS / Linux 的 Gradle Wrapper 启动器 |
| `gradlew.bat` | Windows 的 Gradle Wrapper 启动器 |
| `release/yantu-0.4.0.apk` | 已交付的正式安装包 |
| `settings.gradle.kts` | 依赖仓库与模块列表 |
| `signing/README.md` | 本机签名说明 |
