# 在电脑运行与尝试修改

## 打开工程

1. 使用电脑上的 Android Studio，选择打开项目，选中含 `settings.gradle.kts` 的这一层目录。
2. 该工程配置使用 JDK 17、Android SDK Platform 35、Build Tools 35.0.0、Gradle 8.11.1；插件版本已写在根构建文件中。新版本开发工具可用其兼容的 JDK 运行，按同步提示配置即可。
3. 安装所需 SDK 并等待依赖同步。首次同步和下载 Gradle、依赖需要联网。
4. 连接开启 USB 调试的安卓手机，或启动 Android 模拟器，在工具栏运行 `app`。

最低系统要求为 Android 8.0。测试修改时可以使用模拟器，避免把练习数据和手机正式记录混在一起。

## 命令行构建

在项目根目录执行：

macOS / Linux：

```sh
./gradlew :app:assembleDebug :app:testDebugUnitTest
```

Windows：

```bat
gradlew.bat :app:assembleDebug :app:testDebugUnitTest
```

Debug 输出为 `app/build/outputs/apk/debug/app-debug.apk`。

正式构建使用：

```sh
./gradlew :app:assembleRelease
```

公开源码不携带发布私钥，Release 输出位于 `app/build/outputs/apk/release/`（未签名时通常为 `app-release-unsigned.apk`）。请在本机通过 Android Studio 的生成签名 APK 流程使用原私钥完成正式签名。`release/yantu-0.4.0.apk` 是先前交付、可直接安装的版本。注释影响源码行号等构建信息，重新构建后的文件摘要不一定与交付 APK 完全相同；本公开版本保留业务功能代码，签名由构建者在本机配置。

若命令行找不到 SDK，在 Android Studio 的 SDK 设置中确认位置，并在本机设置 `ANDROID_HOME`，或创建包含本机 `sdk.dir` 的 `local.properties`。该路径因电脑而异。

## 先做三个小练习

| 练习 | 去哪里修改 | 看什么效果 |
| --- | --- | --- |
| 换一句首页文字 | `MainActivity.kt`，搜索“每一套真题，都算数。” | 重新运行后首页文案变化 |
| 改分数标签字号 | `StatisticsPage.kt / ScoreTrend()`，找 `10.sp.toPx()` | 统计页分数标签大小变化，留意是否遮挡 |
| 改倒计时到期文字 | `Countdown.kt / countdownText()` | 同时查看并调整 `CountdownTest.kt` 对应预期 |

再尝试只改 `AiAnalyzer.instruction()` 的输出要求，例如要求每个薄弱点给一道练习建议。它改变发给模型的指令，仍需你配置可用 API 才能看到真实模型回复。

每次先改一小处，编译运行，确认效果再继续。涉及数据库表名、主键、安装标识和签名时，先读原工程 README 中的兼容说明；正式数据先做完整备份。

## 测试文件怎样帮助你理解

`CountdownTest` 固定日期，看倒计时文字；`ScorePartsTest` 给出合法和不合法分数；`RulesAndAiTest` 覆盖政治计分、满分口径和模拟网络；`UpgradeTest` 检查旧记录与 ZIP 恢复。测试中有输入和预期输出，适合作为实际例子阅读。

网络测试使用模拟连接，不会消耗真实 API 费用。真实服务商的可用性仍取决于你的模型、密钥、余额和网络。
